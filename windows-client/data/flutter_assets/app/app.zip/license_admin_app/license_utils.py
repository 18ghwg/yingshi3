from __future__ import annotations

from pathlib import Path


_SHARED = Path(__file__).resolve().with_name("_shared_license_utils.py")

if not _SHARED.exists():
    raise FileNotFoundError(f"找不到共享授权逻辑文件: {_SHARED}")

_namespace: dict[str, object] = {}
exec(_SHARED.read_text(encoding="utf-8"), _namespace)
globals().update(_namespace)
