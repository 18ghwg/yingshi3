from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from datetime import timedelta
import base64
import hashlib
import hmac
import json
import os
from pathlib import Path
import platform
import re
import time
import subprocess
import uuid

try:
    import winreg
except ImportError:  # pragma: no cover - only occurs on non-Windows Python runtimes
    winreg = None


LICENSE_DIR_NAME = ".wsruntime"
LICENSE_FILE_NAME = ".sys_license.dat"
TIME_STATE_FILE_NAME = ".time_state.dat"
LICENSE_ENV_SECRET = "WORKSHOP_LICENSE_SECRET"
DEFAULT_LICENSE_SECRET = "workshop-duration-stats-2026"
TIME_ROLLBACK_TOLERANCE_SECONDS = 300
REBOOT_MONOTONIC_RESET_THRESHOLD = 30


class LicenseError(ValueError):
    pass


@dataclass(frozen=True)
class LicensePayload:
    machine_code: str
    expires_on: date


@dataclass(frozen=True)
class TimeCheckResult:
    is_valid: bool
    message: str = ""
    current_time: datetime | None = None


def _license_secret() -> bytes:
    return os.getenv(LICENSE_ENV_SECRET, DEFAULT_LICENSE_SECRET).encode("utf-8")


def _xor_bytes(data: bytes, key: bytes) -> bytes:
    return bytes(byte ^ key[index % len(key)] for index, byte in enumerate(data))


def _machine_fingerprint_source() -> str:
    parts: list[str] = []
    if os.name == "nt":
        parts.extend(
            [
                _read_windows_username(),
                _read_windows_machine_guid(),
                _read_windows_disk_serial(),
                _read_windows_system_drive_volume_serial(),
                platform.machine(),
                platform.system(),
            ]
        )
    else:
        parts.extend(
            [
                os.getenv("USER", ""),
                platform.machine(),
                platform.system(),
            ]
        )

    normalized_parts = _unique_fingerprint_parts(parts)
    if not normalized_parts:
        normalized_parts = _unique_fingerprint_parts(
            [
                platform.system(),
                platform.machine(),
                hex(uuid.getnode()),
            ]
        )
    return "|".join(normalized_parts)


def _unique_fingerprint_parts(parts: list[str]) -> list[str]:
    unique_parts: list[str] = []
    seen: set[str] = set()
    for part in parts:
        normalized = _normalize_fingerprint_part(part)
        if normalized and normalized not in seen:
            seen.add(normalized)
            unique_parts.append(normalized)
    return unique_parts


def _normalize_fingerprint_part(value: object) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    return " ".join(text.split()).upper()


def _read_windows_username() -> str:
    if os.name != "nt":
        return ""
    return os.getenv("USERNAME", "").strip()


def _read_windows_machine_guid() -> str:
    if os.name != "nt" or winreg is None:
        return ""

    access = winreg.KEY_READ
    if hasattr(winreg, "KEY_WOW64_64KEY"):
        access |= winreg.KEY_WOW64_64KEY

    try:
        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Cryptography",
            0,
            access,
        ) as key:
            value, _ = winreg.QueryValueEx(key, "MachineGuid")
    except Exception:  # noqa: BLE001
        return ""
    return str(value).strip()


def _read_windows_disk_serial() -> str:
    if os.name != "nt":
        return ""
    commands = [
        [
            "powershell",
            "-NoProfile",
            "-Command",
            "(Get-CimInstance Win32_PhysicalMedia | Where-Object { $_.SerialNumber } | "
            "Select-Object -First 1 -ExpandProperty SerialNumber)",
        ],
        [
            "powershell",
            "-NoProfile",
            "-Command",
            "(Get-CimInstance Win32_DiskDrive | Where-Object { $_.SerialNumber } | "
            "Select-Object -First 1 -ExpandProperty SerialNumber)",
        ],
        ["wmic", "diskdrive", "get", "SerialNumber"],
    ]

    for command in commands:
        serial_number = _run_fingerprint_command(command, ignored_values={"SERIALNUMBER"})
        if serial_number:
            return serial_number
    return ""


def _read_windows_system_drive_volume_serial() -> str:
    if os.name != "nt":
        return ""

    system_drive = os.getenv("SystemDrive", "C:").strip() or "C:"
    output = _run_fingerprint_command(["cmd", "/c", "vol", system_drive])
    if not output:
        return ""

    match = re.search(r"([A-F0-9]{4}-[A-F0-9]{4})", output.upper())
    if match:
        return match.group(1)
    return ""


def _run_fingerprint_command(command: list[str], ignored_values: set[str] | None = None) -> str:
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
    except Exception:  # noqa: BLE001
        return ""

    if completed.returncode != 0:
        return ""

    ignored = ignored_values or set()
    for line in completed.stdout.splitlines():
        value = _normalize_fingerprint_part(line)
        if value and value not in ignored:
            return value
    return ""


def get_machine_code() -> str:
    digest = hashlib.sha256(_machine_fingerprint_source().encode("utf-8")).hexdigest().upper()
    groups = [digest[index : index + 4] for index in range(0, 20, 4)]
    return "-".join(groups)


def serialize_license_payload(payload: LicensePayload) -> str:
    return json.dumps(
        {
            "v": 1,
            "machine_code": payload.machine_code,
            "expires_on": payload.expires_on.isoformat(),
        },
        ensure_ascii=True,
        separators=(",", ":"),
        sort_keys=True,
    )


def generate_license_key(machine_code: str, expires_on: date) -> str:
    normalized_machine_code = machine_code.strip().upper()
    if not normalized_machine_code:
        raise LicenseError("机器码不能为空。")

    payload_text = serialize_license_payload(
        LicensePayload(machine_code=normalized_machine_code, expires_on=expires_on)
    )
    payload_bytes = payload_text.encode("utf-8")
    encrypted_payload = _xor_bytes(payload_bytes, hashlib.sha256(_license_secret()).digest())
    payload_part = base64.urlsafe_b64encode(encrypted_payload).decode("ascii").rstrip("=")
    signature = hmac.new(_license_secret(), payload_bytes, hashlib.sha256).hexdigest().upper()
    return f"WK1-{payload_part}.{signature}"


def decode_license_key(license_key: str) -> LicensePayload:
    normalized_key = license_key.strip()
    if not normalized_key:
        raise LicenseError("授权码不能为空。")

    try:
        if normalized_key.startswith("WK1-"):
            normalized_key = normalized_key[4:]
        payload_part, signature_part = normalized_key.split(".", 1)
        encrypted_payload = base64.urlsafe_b64decode(_pad_base64(payload_part))
    except Exception as exc:  # noqa: BLE001
        raise LicenseError("授权码格式无效。") from exc

    try:
        payload_bytes = _xor_bytes(encrypted_payload, hashlib.sha256(_license_secret()).digest())
        json_text = payload_bytes.decode("utf-8")
        payload_dict = json.loads(json_text)
    except Exception as exc:  # noqa: BLE001
        raise LicenseError("授权码无法解密。")

    expected_signature = hmac.new(
        _license_secret(),
        json_text.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest().upper()
    if signature_part.upper() != expected_signature:
        raise LicenseError("授权码签名校验失败。")

    machine_code = str(payload_dict.get("machine_code", "")).strip().upper()
    expires_text = str(payload_dict.get("expires_on", "")).strip()
    if not machine_code or not expires_text:
        raise LicenseError("授权码缺少必要字段。")

    try:
        expires_on = date.fromisoformat(expires_text)
    except ValueError as exc:
        raise LicenseError("授权码中的到期日期无效。") from exc

    return LicensePayload(machine_code=machine_code, expires_on=expires_on)


def validate_license_key(license_key: str, current_machine_code: str, today: date | None = None) -> LicensePayload:
    payload = decode_license_key(license_key)
    normalized_machine_code = current_machine_code.strip().upper()
    if payload.machine_code != normalized_machine_code:
        raise LicenseError("授权码绑定的机器码与当前电脑不匹配。")

    compare_date = today or date.today()
    if payload.expires_on < compare_date:
        raise LicenseError(f"授权已过期，到期日期为 {payload.expires_on.isoformat()}。")
    return payload


def get_license_storage_dir(base_dir: Path | None = None) -> Path:
    if base_dir is not None:
        return base_dir
    if os.name == "nt":
        local_appdata = os.getenv("LOCALAPPDATA", "").strip()
        if local_appdata:
            return Path(local_appdata) / LICENSE_DIR_NAME
        appdata = os.getenv("APPDATA", "").strip()
        if appdata:
            return Path(appdata) / LICENSE_DIR_NAME
        home = Path.home()
        return home / "AppData" / "Local" / LICENSE_DIR_NAME
    return Path.home() / f".{LICENSE_DIR_NAME.lstrip('.')}"


def get_license_file_path(base_dir: Path | None = None) -> Path:
    return get_license_storage_dir(base_dir) / LICENSE_FILE_NAME


def get_time_state_file_path(base_dir: Path | None = None) -> Path:
    return get_license_storage_dir(base_dir) / "state" / TIME_STATE_FILE_NAME


def save_activated_license(license_key: str, base_dir: Path | None = None) -> Path:
    target = get_license_file_path(base_dir)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload_text = json.dumps({"license_key": license_key.strip()}, ensure_ascii=True, indent=2)
    _replace_text_file(target, payload_text)
    _set_hidden_if_windows(target.parent)
    _set_hidden_if_windows(target)
    return target


def load_saved_license(base_dir: Path | None = None) -> str:
    target = get_license_file_path(base_dir)
    if not target.exists():
        legacy_target = get_legacy_license_file_path(base_dir)
        if legacy_target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            legacy_target.replace(target)
            _set_hidden_if_windows(target.parent)
            _set_hidden_if_windows(target)
    if not target.exists():
        return ""
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise LicenseError("本地激活文件损坏，无法读取。") from exc
    return str(data.get("license_key", "")).strip()


def clear_saved_license(base_dir: Path | None = None) -> None:
    target = get_license_file_path(base_dir)
    if target.exists():
        _clear_hidden_readonly_if_windows(target)
        target.unlink()
    legacy_target = get_legacy_license_file_path(base_dir)
    if legacy_target.exists():
        _clear_hidden_readonly_if_windows(legacy_target)
        legacy_target.unlink()


def get_legacy_license_file_path(base_dir: Path | None = None) -> Path:
    if base_dir is not None:
        return base_dir / "license.json"
    appdata = os.getenv("APPDATA", "").strip()
    if appdata:
        return Path(appdata) / "workshop-duration-stats" / "license.json"
    return Path.cwd() / "license.json"


def _set_hidden_if_windows(target: Path) -> None:
    if os.name != "nt" or not target.exists():
        return
    try:
        subprocess.run(
            ["attrib", "+h", str(target)],
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
    except Exception:  # noqa: BLE001
        return


def _clear_hidden_readonly_if_windows(target: Path) -> None:
    if os.name != "nt" or not target.exists():
        return
    try:
        subprocess.run(
            ["attrib", "-r", "-h", str(target)],
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
    except Exception:  # noqa: BLE001
        return


def _clear_hidden_if_windows(target: Path) -> None:
    if os.name != "nt" or not target.exists():
        return
    try:
        subprocess.run(
            ["attrib", "-h", str(target)],
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
    except Exception:  # noqa: BLE001
        return


def _pad_base64(value: str) -> bytes:
    padding = (-len(value)) % 4
    return (value + ("=" * padding)).encode("ascii")


def verify_system_time_integrity(base_dir: Path | None = None) -> TimeCheckResult:
    current_wall_time = datetime.now()
    current_monotonic = time.monotonic()
    target = get_time_state_file_path(base_dir)

    previous_state = _load_time_state(target)
    if previous_state is not None:
        previous_wall_time = datetime.fromisoformat(previous_state["wall_time"])
        previous_monotonic = float(previous_state["monotonic"])
        monotonic_delta = current_monotonic - previous_monotonic
        expected_minimum_time = previous_wall_time + timedelta(
            seconds=max(monotonic_delta - TIME_ROLLBACK_TOLERANCE_SECONDS, 0)
        )
        if current_wall_time + timedelta(seconds=TIME_ROLLBACK_TOLERANCE_SECONDS) < previous_wall_time:
            return TimeCheckResult(
                is_valid=False,
                message="检测到系统时间被回拨，请恢复系统时间后再使用软件。",
                current_time=current_wall_time,
            )
        if monotonic_delta >= REBOOT_MONOTONIC_RESET_THRESHOLD and current_wall_time + timedelta(
            seconds=TIME_ROLLBACK_TOLERANCE_SECONDS
        ) < expected_minimum_time:
            return TimeCheckResult(
                is_valid=False,
                message="检测到系统时间异常，请把系统时间恢复到正确时间后再继续使用。",
                current_time=current_wall_time,
            )

    _save_time_state(target, current_wall_time, current_monotonic)
    return TimeCheckResult(is_valid=True, current_time=current_wall_time)


def refresh_time_integrity_state(base_dir: Path | None = None, current_time: datetime | None = None) -> None:
    target = get_time_state_file_path(base_dir)
    wall_time = current_time or datetime.now()
    _save_time_state(target, wall_time, time.monotonic())


def _load_time_state(target: Path) -> dict[str, object] | None:
    if not target.exists():
        return None
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise LicenseError("本地时间校验状态损坏，无法读取。") from exc
    if "wall_time" not in data or "monotonic" not in data:
        raise LicenseError("本地时间校验状态缺失必要字段。")
    return data


def _save_time_state(target: Path, wall_time: datetime, monotonic_value: float) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    _replace_text_file(
        target,
        json.dumps(
            {
                "wall_time": wall_time.isoformat(),
                "monotonic": monotonic_value,
            },
            ensure_ascii=True,
            indent=2,
        ),
    )
    _set_hidden_if_windows(target.parent)
    _set_hidden_if_windows(target)


def _replace_text_file(target: Path, content: str) -> None:
    temp_target = target.with_name(f"{target.name}.tmp")
    temp_target.write_text(content, encoding="utf-8")
    if target.exists():
        _clear_hidden_readonly_if_windows(target)
    temp_target.replace(target)
