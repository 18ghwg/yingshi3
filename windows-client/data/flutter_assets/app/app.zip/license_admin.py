from __future__ import annotations

from datetime import date, datetime
import os
import sys

import flet as ft

from license_utils import LicenseError, decode_license_key, generate_license_key


def normalize_expire_date(value: object) -> date:
    if isinstance(value, datetime):
        if value.tzinfo is not None:
            return value.astimezone().date()
        return value.date()
    if isinstance(value, date):
        return value

    text = str(value or "").strip()
    if not text:
        raise ValueError("到期日期不能为空。")

    try:
        return date.fromisoformat(text)
    except ValueError:
        pass

    try:
        parsed = datetime.fromisoformat(text)
    except ValueError as exc:
        raise ValueError(f"无效的到期日期格式: {text}") from exc

    if parsed.tzinfo is not None:
        return parsed.astimezone().date()
    return parsed.date()


class LicenseAdminApp:
    def __init__(self, page: ft.Page) -> None:
        self.page = page
        self.page.title = "车间时长统计 - 管理员注册机"
        self.page.window.width = 900
        self.page.window.height = 760
        self.page.theme_mode = ft.ThemeMode.LIGHT
        self.page.padding = 24
        self.page.bgcolor = "#edf4f7"
        self.page.scroll = ft.ScrollMode.AUTO

        self.clipboard = ft.Clipboard()
        self.page.services.append(self.clipboard)

        today = datetime.now().date()
        self.expire_date_picker = ft.DatePicker(
            value=today,
            first_date=date(2020, 1, 1),
            last_date=date(2050, 12, 31),
            locale=ft.Locale("zh", "CN"),
            field_label_text="到期日期",
            help_text="选择授权到期日期",
            on_change=self._on_expire_date_change,
        )
        self.page.overlay.append(self.expire_date_picker)

        self.machine_code_input = ft.TextField(
            label="机器码",
            hint_text="输入客户端显示的机器码",
            filled=True,
            border_radius=16,
            bgcolor="#ffffff",
        )
        self.expire_date_field = ft.TextField(
            label="到期日期",
            value=today.isoformat(),
            read_only=True,
            width=180,
            dense=True,
            filled=True,
            border_radius=14,
            bgcolor="#ffffff",
            on_click=self.open_expire_date_picker,
        )
        self.license_output = ft.TextField(
            label="生成的授权码",
            multiline=True,
            min_lines=4,
            max_lines=8,
            read_only=True,
            filled=True,
            border_radius=16,
            bgcolor="#ffffff",
        )
        self.preview_text = ft.Text("", size=13, color="#52606d")

        self.page.add(
            ft.Container(
                padding=ft.Padding.all(24),
                border_radius=28,
                gradient=ft.LinearGradient(
                    begin=ft.Alignment(-1, -1),
                    end=ft.Alignment(1, 1),
                    colors=["#532e1c", "#8c4f2b", "#d17a22"],
                ),
                content=ft.Column(
                    spacing=8,
                    controls=[
                        ft.Text("管理员注册机", size=30, weight=ft.FontWeight.BOLD, color="#ffffff"),
                        ft.Text("根据机器码和到期日期生成一机一授权的授权码。", size=15, color="#fff1dd"),
                    ],
                ),
            ),
            ft.Container(
                margin=ft.Margin.only(top=18),
                padding=ft.Padding.all(22),
                border_radius=28,
                bgcolor="#ffffff",
                content=ft.Column(
                    spacing=14,
                    controls=[
                        self.machine_code_input,
                        self.expire_date_field,
                        ft.Row(
                            spacing=10,
                            controls=[
                                self._action_button("选择日期", ft.Icons.CALENDAR_MONTH, self.open_expire_date_picker, "#145da0"),
                                self._action_button("生成授权码", ft.Icons.KEY, self.generate_license, "#7a3e00"),
                                self._action_button("复制授权码", ft.Icons.CONTENT_COPY, self.copy_license, "#0b6e4f"),
                                self._action_button("解析校验", ft.Icons.FACT_CHECK, self.preview_license, "#6b7280"),
                            ],
                        ),
                        self.license_output,
                        self.preview_text,
                    ],
                ),
            ),
        )

    def _action_button(self, text: str, icon: str, on_click, color: str) -> ft.Container:
        return ft.Container(
            content=ft.Button(
                content=text,
                icon=icon,
                on_click=on_click,
                style=ft.ButtonStyle(
                    color="#ffffff",
                    bgcolor=color,
                    padding=ft.Padding.symmetric(horizontal=20, vertical=16),
                    shape=ft.RoundedRectangleBorder(radius=14),
                ),
            ),
        )

    def open_expire_date_picker(self, _=None) -> None:
        self.expire_date_picker.open = True
        self.page.update()

    def _on_expire_date_change(self, event: ft.ControlEvent) -> None:
        value = event.control.value
        if value:
            self.expire_date_field.value = normalize_expire_date(value).isoformat()
            self.page.update()

    def generate_license(self, _=None) -> None:
        machine_code = self.machine_code_input.value.strip().upper()
        try:
            expires_on = normalize_expire_date(self.expire_date_field.value)
            license_key = generate_license_key(machine_code, expires_on)
            self.license_output.value = license_key
            self.preview_text.value = f"已生成授权码，绑定机器码 {machine_code}，到期日期 {expires_on.isoformat()}。"
            self.preview_text.color = "#0b6e4f"
            self.page.update()
        except (ValueError, LicenseError) as exc:
            self.preview_text.value = f"生成失败：{exc}"
            self.preview_text.color = "#b42318"
            self.page.update()

    async def copy_license(self, _=None) -> None:
        if not self.license_output.value.strip():
            self.preview_text.value = "当前没有可复制的授权码。"
            self.preview_text.color = "#b42318"
            self.page.update()
            return
        await self.clipboard.set(self.license_output.value.strip())
        self.preview_text.value = "授权码已复制到剪贴板。"
        self.preview_text.color = "#0b6e4f"
        self.page.update()

    def preview_license(self, _=None) -> None:
        license_key = self.license_output.value.strip()
        try:
            payload = decode_license_key(license_key)
            self.preview_text.value = (
                f"授权信息：机器码 {payload.machine_code}，到期日期 {payload.expires_on.isoformat()}。"
            )
            self.preview_text.color = "#145da0"
            self.page.update()
        except LicenseError as exc:
            self.preview_text.value = f"解析失败：{exc}"
            self.preview_text.color = "#b42318"
            self.page.update()


def main(page: ft.Page) -> None:
    LicenseAdminApp(page)


def run_app() -> None:
    force_mode = ""
    if "--web" in sys.argv:
        force_mode = "web"
    elif "--desktop" in sys.argv:
        force_mode = "desktop"
    else:
        force_mode = os.getenv("WORKSHOP_ADMIN_VIEW", "").strip().lower()

    if force_mode == "web":
        ft.run(main, view=ft.AppView.WEB_BROWSER)
        return

    if force_mode == "desktop":
        ft.run(main, view=ft.AppView.FLET_APP)
        return

    ft.run(main, view=ft.AppView.FLET_APP)


if __name__ == "__main__":
    run_app()
