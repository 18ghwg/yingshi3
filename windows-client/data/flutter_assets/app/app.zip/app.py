from __future__ import annotations

import asyncio
from datetime import date, datetime, time, timedelta
import os
from pathlib import Path
import sys

import flet as ft
import pandas as pd

from license_utils import (
    LicenseError,
    clear_saved_license,
    get_machine_code,
    load_saved_license,
    refresh_time_integrity_state,
    save_activated_license,
    validate_license_key,
    verify_system_time_integrity,
)
from workshop_stats import (
    DEFAULT_DUPLICATE_SECONDS,
    InMemoryFile,
    build_data_profile,
    calculate_week_range,
    export_result,
    generate_stats,
    summarize_result,
)


def get_export_base_dir() -> Path:
    packaged_home = os.getenv("PYTHONHOME", "").strip()
    # Official Flet desktop builds run Python from an unpacked app directory,
    # but PYTHONHOME still points to the directory containing the EXE.
    if packaged_home and os.getenv("FLET_APP_STORAGE_DATA"):
        return Path(packaged_home)
    return Path.cwd()


def format_dt(value: pd.Timestamp | datetime | date | None, with_time: bool = True) -> str:
    if value is None or pd.isna(value):
        return ""
    ts = pd.Timestamp(value)
    return ts.strftime("%Y-%m-%d %H:%M:%S" if with_time else "%Y-%m-%d")


def format_date_only(value: pd.Timestamp | datetime | date | None) -> str:
    if value is None or pd.isna(value):
        return ""
    if isinstance(value, pd.Timestamp):
        return value.date().isoformat()
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    return pd.Timestamp(value).date().isoformat()


def safe_text(value: object) -> str:
    if value is None or pd.isna(value):
        return ""
    if isinstance(value, pd.Timestamp):
        return format_dt(value)
    return str(value)


class WorkshopStatsFletApp:
    def __init__(self, page: ft.Page) -> None:
        self.page = page
        self.page.title = "人员出入车间时长统计 - ghwg"
        self.page.window.width = 1440
        self.page.window.height = 920
        self.page.theme_mode = ft.ThemeMode.LIGHT
        self.page.padding = 16
        self.page.bgcolor = "#f3f5f7"
        self.page.scroll = ft.ScrollMode.AUTO
        self.machine_code = get_machine_code()
        self.license_payload = None
        self.license_status_text = ft.Text("", size=13, color="#52606d")
        self.machine_code_field = ft.TextField(
            label="当前电脑机器码",
            value=self.machine_code,
            read_only=True,
            dense=True,
            filled=True,
            border_radius=14,
            bgcolor="#ffffff",
        )
        self.license_input = ft.TextField(
            label="输入卡密或授权码",
            hint_text="粘贴管理员生成的授权码后点击激活",
            multiline=True,
            min_lines=3,
            max_lines=5,
            filled=True,
            border_radius=16,
            bgcolor="#ffffff",
        )
        self.renew_license_input = ft.TextField(
            label="输入新的授权码",
            hint_text="粘贴新的授权码后立即续期",
            multiline=True,
            min_lines=3,
            max_lines=5,
            filled=True,
            border_radius=16,
            bgcolor="#ffffff",
        )
        self.renew_license_status_text = ft.Text("", size=13, color="#52606d")
        self.license_manage_button = ft.OutlinedButton(
            "机器码 / 授权续期",
            icon=ft.Icons.VERIFIED_USER,
            on_click=self.open_license_manage_dialog,
            style=ft.ButtonStyle(
                color="#ffffff",
                side=ft.BorderSide(1, "#d9f2ff"),
                bgcolor="#0f5f8f33",
                padding=ft.Padding.symmetric(horizontal=18, vertical=14),
                shape=ft.RoundedRectangleBorder(radius=999),
            ),
        )

        self.selected_files: list[str] = []
        self.selected_uploads: list[InMemoryFile] = []
        self.selected_names: list[str] = []
        self.selected_worknos: list[str] = []
        self.selected_shifts: list[str] = []
        self.name_search_keyword = ""
        self.workno_search_keyword = ""
        self.shift_search_keyword = ""
        self.result = None
        self.profile = None
        self._is_loading = False
        self._table_scroll_row: ft.Row | None = None
        self._table_drag_surface: ft.GestureDetector | None = None
        self._table_horizontal_pixels = 0.0
        self._table_max_horizontal_scroll = 0.0
        self._table_pending_scroll_target: float | None = None
        self._table_scroll_task_running = False
        self._table_is_dragging = False
        self.page_size = 50
        self.current_page = 1
        self.page_size_dropdown: ft.Dropdown | None = None
        self.page_jump_field: ft.TextField | None = None
        self.pagination_summary_text: ft.Text | None = None

        self.file_picker = ft.FilePicker()
        self.clipboard = ft.Clipboard()
        self.page.services.extend([self.file_picker, self.clipboard])

        now = datetime.now()
        self.start_date_picker = ft.DatePicker(
            value=now.date(),
            first_date=date(2020, 1, 1),
            last_date=date(2035, 12, 31),
            locale=ft.Locale("zh", "CN"),
            field_label_text="开始日期",
            help_text="选择开始日期",
            on_change=self._on_start_date_change,
        )
        self.end_date_picker = ft.DatePicker(
            value=now.date(),
            first_date=date(2020, 1, 1),
            last_date=date(2035, 12, 31),
            locale=ft.Locale("zh", "CN"),
            field_label_text="结束日期",
            help_text="选择结束日期",
            on_change=self._on_end_date_change,
        )
        self.start_time_picker = ft.TimePicker(
            value=now.time().replace(microsecond=0),
            help_text="选择开始时间",
            on_change=self._on_start_time_change,
            hour_format=ft.TimePickerHourFormat.H24,
        )
        self.end_time_picker = ft.TimePicker(
            value=time(23, 59, 59),
            help_text="选择结束时间",
            on_change=self._on_end_time_change,
            hour_format=ft.TimePickerHourFormat.H24,
        )
        self.page.overlay.extend(
            [
                self.start_date_picker,
                self.end_date_picker,
                self.start_time_picker,
                self.end_time_picker,
            ]
        )
        self.start_filter_enabled = False
        self.end_filter_enabled = False

        self.name_input = self._build_multi_select_panel("姓名", "点击展开选择姓名")
        self.workno_input = self._build_multi_select_panel("工号", "点击展开选择工号")
        self.shift_input = self._build_multi_select_panel("班次", "点击展开选择班次")
        self.duplicate_input = ft.TextField(
            label="重复刷脸去重秒数",
            value=str(DEFAULT_DUPLICATE_SECONDS),
            width=170,
            dense=True,
            filled=True,
            border_radius=14,
            bgcolor="#ffffff",
        )

        self.start_date_field = self._build_picker_field("开始日期", self.open_start_date_picker, "")
        self.start_time_field = self._build_picker_field("开始时间", self.open_start_time_picker, "")
        self.end_date_field = self._build_picker_field("结束日期", self.open_end_date_picker, "")
        self.end_time_field = self._build_picker_field("结束时间", self.open_end_time_picker, "")

        self.file_text = ft.Text("未选择文件", color="#4b5563")
        self.range_text = ft.Text("", color="#4b5563", size=13)
        self.summary_text = ft.Text("请先导入 Excel 或 ZIP 文件。", weight=ft.FontWeight.W_600, color="#0f4c81")
        self.loading_indicator = ft.Row(
            visible=False,
            spacing=12,
            controls=[
                ft.ProgressRing(width=20, height=20, stroke_width=2.5),
                ft.Text("正在分析进出车间记录，请稍候...", color="#145da0"),
            ],
        )
        self.tab_loading_indicator = ft.Row(
            visible=False,
            spacing=12,
            controls=[
                ft.ProgressRing(width=20, height=20, stroke_width=2.5),
                ft.Text("正在加载当前标签页数据，请稍候...", color="#145da0"),
            ],
        )

        self.tables_column = ft.Column(scroll=ft.ScrollMode.AUTO, expand=True)
        self.table_loading_overlay = ft.Container(
            visible=False,
            expand=True,
            alignment=ft.Alignment.CENTER,
            bgcolor=ft.Colors.with_opacity(0.74, "#f8fbff"),
            border_radius=18,
            content=ft.Container(
                padding=ft.Padding.symmetric(horizontal=28, vertical=24),
                border_radius=22,
                bgcolor="#ffffff",
                shadow=ft.BoxShadow(
                    blur_radius=24,
                    spread_radius=0,
                    color=ft.Colors.with_opacity(0.18, "#102a43"),
                    offset=ft.Offset(0, 8),
                ),
                content=ft.Column(
                    tight=True,
                    spacing=12,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.ProgressRing(width=34, height=34, stroke_width=3),
                        ft.Text("正在加载数据", size=16, weight=ft.FontWeight.W_700, color="#12344d"),
                        ft.Text("数据较多时需要一点时间，请稍候。", size=12, color="#52606d"),
                    ],
                ),
            ),
        )
        self.tab_bar = ft.Row(
            wrap=True,
            spacing=8,
            controls=[
                ft.OutlinedButton("明细统计", on_click=lambda _: self.switch_tab(0)),
                ft.OutlinedButton("按日汇总", on_click=lambda _: self.switch_tab(1)),
                ft.OutlinedButton("按周汇总", on_click=lambda _: self.switch_tab(2)),
                ft.OutlinedButton("按月汇总", on_click=lambda _: self.switch_tab(3)),
                ft.OutlinedButton("人员主车间", on_click=lambda _: self.switch_tab(4)),
            ],
        )
        self.active_tab_index = 0
        self.page_size_dropdown = ft.Dropdown(
            label="每页条数",
            width=130,
            dense=True,
            filled=True,
            border_radius=14,
            bgcolor="#ffffff",
            value=str(self.page_size),
            options=[
                ft.dropdown.Option("20"),
                ft.dropdown.Option("50"),
                ft.dropdown.Option("100"),
                ft.dropdown.Option("200"),
            ],
            on_select=self._on_page_size_change,
        )
        self.page_jump_field = ft.TextField(
            label="跳转页码",
            width=120,
            dense=True,
            filled=True,
            border_radius=14,
            bgcolor="#ffffff",
            keyboard_type=ft.KeyboardType.NUMBER,
            on_submit=self._jump_to_page,
        )
        self.pagination_summary_text = ft.Text("", size=12, color="#52606d")

        self._build_license_or_main_view()

    def _build_picker_field(self, label: str, on_click, value: str = "") -> ft.TextField:
        return ft.TextField(
            label=label,
            value=value,
            read_only=True,
            width=160,
            dense=True,
            filled=True,
            border_radius=14,
            bgcolor="#ffffff",
            on_click=on_click,
        )

    def _build_multi_select_panel(self, label: str, empty_hint: str) -> ft.Container:
        summary_text = ft.Text(empty_hint, size=13, color="#243b53", no_wrap=True)
        helper_text = ft.Text("展开后可多选、搜索、全选、清空", size=11, color="#7b8794")
        search_input = ft.TextField(
            label=f"搜索{label}",
            dense=True,
            filled=True,
            bgcolor="#ffffff",
        )
        count_text = ft.Text(size=12, color="#52606d")
        list_view = ft.ListView(expand=True, spacing=6, padding=0, height=220)
        tile = ft.ExpansionTile(
            title=ft.Text(label, weight=ft.FontWeight.W_600, color="#102a43"),
            subtitle=summary_text,
            collapsed_bgcolor="#ffffff",
            bgcolor="#f8fbff",
            collapsed_shape=ft.RoundedRectangleBorder(radius=14),
            shape=ft.RoundedRectangleBorder(radius=14),
            controls_padding=ft.Padding.only(left=12, right=12, bottom=12),
            controls=[
                search_input,
                ft.Row(
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    controls=[
                        count_text,
                        ft.Row(
                            spacing=8,
                            controls=[
                                ft.TextButton(f"全选{label}", disabled=True),
                                ft.TextButton("清空", disabled=True),
                            ],
                        ),
                    ],
                ),
                ft.Container(
                    border=ft.Border.all(1, "#d9e2ec"),
                    border_radius=12,
                    padding=10,
                    bgcolor="#ffffff",
                    content=list_view,
                ),
                helper_text,
            ],
        )
        container = ft.Container(width=420, content=tile)
        container.data = {
            "summary": summary_text,
            "helper": helper_text,
            "search": search_input,
            "count": count_text,
            "list": list_view,
            "tile": tile,
            "select_all": tile.controls[1].controls[1].controls[0],
            "clear": tile.controls[1].controls[1].controls[1],
            "empty_hint": empty_hint,
            "label": label,
            "checkboxes": {},
        }
        return container

    def _build_license_or_main_view(self) -> None:
        self.page.controls.clear()
        time_check = self._check_system_time_before_use()
        if not time_check:
            self.license_payload = None
            self._build_license_view()
            self.page.update()
            return
        saved_license = ""
        load_error = ""
        try:
            saved_license = load_saved_license()
        except LicenseError as exc:
            load_error = str(exc)
            clear_saved_license()

        if saved_license:
            try:
                self.license_payload = validate_license_key(saved_license, self.machine_code)
                self._build_main_view()
                self.reset_when_no_files()
                self.show_info(
                    f"授权有效，到期日期 {self.license_payload.expires_on.isoformat()}。"
                )
                return
            except LicenseError as exc:
                load_error = str(exc)
                clear_saved_license()

        self.license_payload = None
        self._build_license_view()
        if load_error:
            self.license_status_text.value = load_error
            self.license_status_text.color = "#b42318"
        self.page.update()

    def _build_license_view(self) -> None:
        self.page.window.width = 860
        self.page.window.height = 720
        self.page.padding = 24
        self.page.bgcolor = "#eef4f7"
        self.license_status_text.value = "软件尚未激活，请输入卡密或授权码。"
        self.license_status_text.color = "#52606d"

        hero = ft.Container(
            padding=ft.Padding.all(24),
            border_radius=28,
            gradient=ft.LinearGradient(
                begin=ft.Alignment(-1, -1),
                end=ft.Alignment(1, 1),
                colors=["#0f3d57", "#177e89", "#57c5b6"],
            ),
            content=ft.Column(
                spacing=8,
                controls=[
                    ft.Text("车间时长统计客户端", size=30, weight=ft.FontWeight.BOLD, color="#ffffff"),
                    ft.Text("请先完成授权激活，再使用统计功能。", size=15, color="#dff8f5"),
                ],
            ),
        )

        activation_card = ft.Container(
            margin=ft.Margin.only(top=18),
            padding=ft.Padding.all(22),
            border_radius=28,
            bgcolor="#ffffff",
            content=ft.Column(
                spacing=14,
                controls=[
                    ft.Text("激活软件", size=22, weight=ft.FontWeight.W_700, color="#12344d"),
                    ft.Text(
                        "把下面的机器码发给管理员，由管理员生成与这台电脑绑定的授权码。",
                        size=13,
                        color="#52606d",
                    ),
                    self.machine_code_field,
                    ft.Row(
                        spacing=10,
                        controls=[
                            self._action_button("复制机器码", ft.Icons.CONTENT_COPY, self.copy_machine_code, "#0b6e4f"),
                            self._action_button("校验本地授权", ft.Icons.VERIFIED_USER, self.recheck_license, "#145da0"),
                            self._action_button("清除本地授权", ft.Icons.DELETE_OUTLINE, self.clear_local_license, "#9a3412"),
                        ],
                    ),
                    self.license_input,
                    ft.Row(
                        spacing=10,
                        controls=[
                            self._action_button("立即激活", ft.Icons.KEY, self.activate_license, "#7a3e00"),
                        ],
                    ),
                    self.license_status_text,
                ],
            ),
        )
        self.page.add(hero, activation_card)

    def _build_main_view(self) -> None:
        self.page.controls.clear()
        self.page.window.width = 1440
        self.page.window.height = 920
        self.page.padding = 16
        self.page.bgcolor = "#f3f5f7"
        self._build_view()

    async def copy_machine_code(self, _=None) -> None:
        await self.clipboard.set(self.machine_code)
        self.license_status_text.value = "机器码已复制到剪贴板，请发送给管理员生成授权码。"
        self.license_status_text.color = "#0b6e4f"
        self.renew_license_status_text.value = "机器码已复制到剪贴板，请发送给管理员生成新的授权码。"
        self.renew_license_status_text.color = "#0b6e4f"
        self.show_info("机器码已复制到剪贴板。")
        self.page.update()

    def recheck_license(self, _=None) -> None:
        try:
            saved_license = load_saved_license()
        except LicenseError as exc:
            self.license_status_text.value = str(exc)
            self.license_status_text.color = "#b42318"
            self.renew_license_status_text.value = str(exc)
            self.renew_license_status_text.color = "#b42318"
            clear_saved_license()
            self.page.update()
            return
        if not saved_license:
            self.license_status_text.value = "当前没有本地授权记录。"
            self.license_status_text.color = "#b42318"
            self.renew_license_status_text.value = "当前没有本地授权记录。"
            self.renew_license_status_text.color = "#b42318"
            self.page.update()
            return

        try:
            payload = validate_license_key(saved_license, self.machine_code)
            self.license_payload = payload
            self.license_status_text.value = f"授权有效，到期日期 {payload.expires_on.isoformat()}。"
            self.license_status_text.color = "#0b6e4f"
            self.renew_license_status_text.value = f"授权有效，到期日期 {payload.expires_on.isoformat()}。"
            self.renew_license_status_text.color = "#0b6e4f"
            self.page.update()
        except LicenseError as exc:
            self.license_status_text.value = str(exc)
            self.license_status_text.color = "#b42318"
            self.renew_license_status_text.value = str(exc)
            self.renew_license_status_text.color = "#b42318"
            self.page.update()

    def activate_license(self, _=None) -> None:
        license_key = self.license_input.value.strip()
        try:
            if not self._check_system_time_before_use():
                return
            payload = validate_license_key(license_key, self.machine_code)
            save_activated_license(license_key)
            refresh_time_integrity_state()
            self.license_payload = payload
            self.license_input.value = ""
            self._build_main_view()
            self.reset_when_no_files()
            self.page.update()
            self.show_info(f"激活成功，授权到期日期 {payload.expires_on.isoformat()}。")
        except LicenseError as exc:
            self.license_status_text.value = str(exc)
            self.license_status_text.color = "#b42318"
            self.page.update()
        except Exception as exc:  # noqa: BLE001
            self.license_status_text.value = f"激活失败：{exc}"
            self.license_status_text.color = "#b42318"
            self.page.update()

    def open_license_manage_dialog(self, _=None) -> None:
        expires_text = (
            self.license_payload.expires_on.isoformat()
            if self.license_payload is not None
            else "当前未检测到有效授权"
        )
        self.renew_license_input.value = ""
        self.renew_license_status_text.value = f"当前授权到期日期：{expires_text}"
        self.renew_license_status_text.color = "#52606d"
        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("机器码与授权续期"),
            content=ft.Container(
                width=620,
                content=ft.Column(
                    tight=True,
                    spacing=14,
                    controls=[
                        ft.Text(
                            "把机器码发给管理员生成新的授权码，输入后可直接覆盖本机授权并延长使用时间。",
                            size=13,
                            color="#52606d",
                        ),
                        ft.TextField(
                            label="本机机器码",
                            value=self.machine_code,
                            read_only=True,
                            dense=True,
                            filled=True,
                            border_radius=14,
                            bgcolor="#f8fafc",
                        ),
                        ft.Row(
                            wrap=True,
                            spacing=10,
                            controls=[
                                self._action_button("复制机器码", ft.Icons.CONTENT_COPY, self.copy_machine_code, "#0b6e4f"),
                                self._action_button("校验当前授权", ft.Icons.VERIFIED_USER, self.recheck_license, "#145da0"),
                            ],
                        ),
                        self.renew_license_input,
                        ft.Row(
                            spacing=10,
                            controls=[
                                self._action_button("立即续期", ft.Icons.KEY, self.activate_license_from_dialog, "#7a3e00"),
                            ],
                        ),
                        self.renew_license_status_text,
                    ],
                ),
            ),
            actions=[ft.TextButton("关闭", on_click=self.close_dialog)],
            actions_alignment=ft.MainAxisAlignment.END,
        )
        self.page.show_dialog(dialog)
        self.page.update()

    def activate_license_from_dialog(self, _=None) -> None:
        license_key = self.renew_license_input.value.strip()
        try:
            if not self._check_system_time_before_use():
                return
            payload = validate_license_key(license_key, self.machine_code)
            save_activated_license(license_key)
            refresh_time_integrity_state()
            self.license_payload = payload
            self.license_input.value = ""
            self.renew_license_input.value = ""
            self.license_status_text.value = f"授权有效，到期日期 {payload.expires_on.isoformat()}。"
            self.license_status_text.color = "#0b6e4f"
            self.renew_license_status_text.value = f"续期成功，新的到期日期为 {payload.expires_on.isoformat()}。"
            self.renew_license_status_text.color = "#0b6e4f"
            self.page.update()
            self.show_info(f"授权已更新，到期日期 {payload.expires_on.isoformat()}。")
        except LicenseError as exc:
            self.renew_license_status_text.value = str(exc)
            self.renew_license_status_text.color = "#b42318"
            self.page.update()
        except Exception as exc:  # noqa: BLE001
            self.renew_license_status_text.value = f"续期失败：{exc}"
            self.renew_license_status_text.color = "#b42318"
            self.page.update()

    def clear_local_license(self, _=None) -> None:
        clear_saved_license()
        self.license_payload = None
        self.license_status_text.value = "本地授权已清除。"
        self.license_status_text.color = "#9a3412"
        self.page.update()

    def ensure_license_active(self) -> bool:
        try:
            if not self._check_system_time_before_use():
                return False
            saved_license = load_saved_license()
            if not saved_license:
                raise LicenseError("当前未找到有效授权，请先激活软件。")
            self.license_payload = validate_license_key(saved_license, self.machine_code)
            refresh_time_integrity_state()
            return True
        except LicenseError as exc:
            clear_saved_license()
            self.license_payload = None
            self.page.controls.clear()
            self._build_license_view()
            self.license_status_text.value = str(exc)
            self.license_status_text.color = "#b42318"
            self.page.update()
            return False

    def _check_system_time_before_use(self) -> bool:
        try:
            result = verify_system_time_integrity()
        except LicenseError as exc:
            self.license_status_text.value = str(exc)
            self.license_status_text.color = "#b42318"
            self.renew_license_status_text.value = str(exc)
            self.renew_license_status_text.color = "#b42318"
            return False
        except Exception as exc:  # noqa: BLE001
            message = f"本地授权状态写入失败：{exc}"
            self.license_status_text.value = message
            self.license_status_text.color = "#b42318"
            self.renew_license_status_text.value = message
            self.renew_license_status_text.color = "#b42318"
            return False

        if result.is_valid:
            return True

        self.license_status_text.value = result.message
        self.license_status_text.color = "#b42318"
        self.renew_license_status_text.value = result.message
        self.renew_license_status_text.color = "#b42318"
        self.show_error(result.message)
        return False

    def _available_name_options(self) -> list[str]:
        if self.profile is not None:
            if self.result is not None and not self.result.primary_areas.empty:
                pairs = self.result.primary_areas[["人员姓名", "工号", "班次"]].drop_duplicates().copy()
                if self.selected_worknos:
                    pairs = pairs[pairs["工号"].isin(self.selected_worknos)]
                if self.selected_shifts:
                    pairs = pairs[pairs["班次"].isin(self.selected_shifts)]
                if not pairs.empty:
                    return sorted(value for value in pairs["人员姓名"].dropna().unique() if value)
            return self.profile.names
        return []

    def _available_workno_options(self) -> list[str]:
        if self.profile is not None:
            if self.result is not None and not self.result.primary_areas.empty:
                pairs = self.result.primary_areas[["人员姓名", "工号", "班次"]].drop_duplicates().copy()
                if self.selected_names:
                    pairs = pairs[pairs["人员姓名"].isin(self.selected_names)]
                if self.selected_shifts:
                    pairs = pairs[pairs["班次"].isin(self.selected_shifts)]
                if not pairs.empty:
                    return sorted(value for value in pairs["工号"].dropna().unique() if value)
            return self.profile.worknos
        return []

    def _available_shift_options(self) -> list[str]:
        if self.profile is not None:
            if self.result is not None and not self.result.primary_areas.empty:
                pairs = self.result.primary_areas[["人员姓名", "工号", "班次"]].drop_duplicates().copy()
                if self.selected_names:
                    pairs = pairs[pairs["人员姓名"].isin(self.selected_names)]
                if self.selected_worknos:
                    pairs = pairs[pairs["工号"].isin(self.selected_worknos)]
                if not pairs.empty:
                    return sorted(value for value in pairs["班次"].dropna().unique() if value)
            return self.profile.shifts
        return []

    def _summarize_selected_values(self, values: list[str], empty_hint: str) -> str:
        if not values:
            return empty_hint
        if len(values) <= 2:
            return "；".join(values)
        preview = "；".join(values[:2])
        return f"已选 {len(values)} 项: {preview} ..."

    def _refresh_filter_fields(self) -> None:
        self.name_input.data["summary"].value = self._summarize_selected_values(self.selected_names, "点击展开选择姓名")
        self.workno_input.data["summary"].value = self._summarize_selected_values(self.selected_worknos, "点击展开选择工号")
        self.shift_input.data["summary"].value = self._summarize_selected_values(self.selected_shifts, "点击展开选择班次")
        self._refresh_filter_hints()
        self._refresh_name_selector()
        self._refresh_workno_selector()
        self._refresh_shift_selector()

    def _sync_filter_selections(self) -> None:
        available_names = set(self._available_name_options())
        available_worknos = set(self._available_workno_options())
        available_shifts = set(self._available_shift_options())
        self.selected_names = [value for value in self.selected_names if value in available_names]
        self.selected_worknos = [value for value in self.selected_worknos if value in available_worknos]
        self.selected_shifts = [value for value in self.selected_shifts if value in available_shifts]
        self._refresh_filter_fields()

    def _refresh_selector_panel(
        self,
        container: ft.Container,
        options: list[str],
        selected_values: list[str],
        keyword: str,
        on_search_change,
        on_checkbox_change,
        on_select_all,
        on_clear,
    ) -> None:
        search_input = container.data["search"]
        count_text = container.data["count"]
        list_view = container.data["list"]
        select_all_button = container.data["select_all"]
        clear_button = container.data["clear"]
        checkbox_map = container.data["checkboxes"]

        if search_input.on_change is None:
            search_input.on_change = on_search_change
        if select_all_button.on_click is None:
            select_all_button.on_click = on_select_all
        if clear_button.on_click is None:
            clear_button.on_click = on_clear

        if search_input.value != keyword:
            search_input.value = keyword

        visible_options = options
        normalized_keyword = keyword.strip().lower()
        if normalized_keyword:
            visible_options = [option for option in options if normalized_keyword in option.lower()]

        controls: list[ft.Control] = []
        if visible_options:
            for option in visible_options:
                checkbox = checkbox_map.get(option)
                if checkbox is None:
                    checkbox = ft.Checkbox(label=option, data=option, on_change=on_checkbox_change)
                    checkbox_map[option] = checkbox
                checkbox.value = option in selected_values
                controls.append(
                    ft.Container(
                        padding=ft.Padding.symmetric(horizontal=8, vertical=2),
                        border_radius=10,
                        bgcolor="#f8fafc",
                        content=checkbox,
                    )
                )
        else:
            controls.append(
                ft.Container(
                    padding=12,
                    border_radius=10,
                    bgcolor="#f8fafc",
                    content=ft.Text("没有匹配项。", color="#52606d"),
                )
            )

        list_view.controls = controls
        count_text.value = f"共 {len(options)} 项，当前显示 {len(visible_options)} 项，已选 {len(selected_values)} 项"
        select_all_button.disabled = not bool(visible_options)
        clear_button.disabled = not bool(selected_values)

    def _on_name_search_change(self, event: ft.ControlEvent) -> None:
        self.name_search_keyword = event.control.value or ""
        self._refresh_name_selector()
        self.page.update()

    def _on_workno_search_change(self, event: ft.ControlEvent) -> None:
        self.workno_search_keyword = event.control.value or ""
        self._refresh_workno_selector()
        self.page.update()

    def _on_shift_search_change(self, event: ft.ControlEvent) -> None:
        self.shift_search_keyword = event.control.value or ""
        self._refresh_shift_selector()
        self.page.update()

    def _on_name_checkbox_change(self, event: ft.ControlEvent) -> None:
        option = event.control.data
        if event.control.value and option not in self.selected_names:
            self.selected_names.append(option)
        if not event.control.value and option in self.selected_names:
            self.selected_names.remove(option)
        self.selected_names.sort()
        self.selected_worknos = [value for value in self.selected_worknos if value in set(self._available_workno_options())]
        self.selected_shifts = [value for value in self.selected_shifts if value in set(self._available_shift_options())]
        self._refresh_filter_fields()
        self.page.update()
        if self.selected_files or self.selected_uploads:
            self.run_stats_async(show_success=False)

    def _on_workno_checkbox_change(self, event: ft.ControlEvent) -> None:
        option = event.control.data
        if event.control.value and option not in self.selected_worknos:
            self.selected_worknos.append(option)
        if not event.control.value and option in self.selected_worknos:
            self.selected_worknos.remove(option)
        self.selected_worknos.sort()
        self.selected_names = [value for value in self.selected_names if value in set(self._available_name_options())]
        self.selected_shifts = [value for value in self.selected_shifts if value in set(self._available_shift_options())]
        self._refresh_filter_fields()
        self.page.update()
        if self.selected_files or self.selected_uploads:
            self.run_stats_async(show_success=False)

    def _on_shift_checkbox_change(self, event: ft.ControlEvent) -> None:
        option = event.control.data
        if event.control.value and option not in self.selected_shifts:
            self.selected_shifts.append(option)
        if not event.control.value and option in self.selected_shifts:
            self.selected_shifts.remove(option)
        self.selected_shifts.sort()
        self.selected_names = [value for value in self.selected_names if value in set(self._available_name_options())]
        self.selected_worknos = [value for value in self.selected_worknos if value in set(self._available_workno_options())]
        self._refresh_filter_fields()
        self.page.update()
        if self.selected_files or self.selected_uploads:
            self.run_stats_async(show_success=False)

    def _select_all_names(self, _event: ft.ControlEvent) -> None:
        options = self._available_name_options()
        keyword = self.name_search_keyword.strip().lower()
        visible_options = [option for option in options if keyword in option.lower()] if keyword else options
        self.selected_names = sorted(set(self.selected_names).union(visible_options))
        self.selected_worknos = [value for value in self.selected_worknos if value in set(self._available_workno_options())]
        self.selected_shifts = [value for value in self.selected_shifts if value in set(self._available_shift_options())]
        self._refresh_filter_fields()
        self.page.update()
        if self.selected_files or self.selected_uploads:
            self.run_stats_async(show_success=False)

    def _select_all_worknos(self, _event: ft.ControlEvent) -> None:
        options = self._available_workno_options()
        keyword = self.workno_search_keyword.strip().lower()
        visible_options = [option for option in options if keyword in option.lower()] if keyword else options
        self.selected_worknos = sorted(set(self.selected_worknos).union(visible_options))
        self.selected_names = [value for value in self.selected_names if value in set(self._available_name_options())]
        self.selected_shifts = [value for value in self.selected_shifts if value in set(self._available_shift_options())]
        self._refresh_filter_fields()
        self.page.update()
        if self.selected_files or self.selected_uploads:
            self.run_stats_async(show_success=False)

    def _select_all_shifts(self, _event: ft.ControlEvent) -> None:
        options = self._available_shift_options()
        keyword = self.shift_search_keyword.strip().lower()
        visible_options = [option for option in options if keyword in option.lower()] if keyword else options
        self.selected_shifts = sorted(set(self.selected_shifts).union(visible_options))
        self.selected_names = [value for value in self.selected_names if value in set(self._available_name_options())]
        self.selected_worknos = [value for value in self.selected_worknos if value in set(self._available_workno_options())]
        self._refresh_filter_fields()
        self.page.update()
        if self.selected_files or self.selected_uploads:
            self.run_stats_async(show_success=False)

    def _clear_name_selection(self, _event: ft.ControlEvent) -> None:
        self.selected_names = []
        self._refresh_filter_fields()
        self.page.update()
        if self.selected_files or self.selected_uploads:
            self.run_stats_async(show_success=False)

    def _clear_workno_selection(self, _event: ft.ControlEvent) -> None:
        self.selected_worknos = []
        self._refresh_filter_fields()
        self.page.update()
        if self.selected_files or self.selected_uploads:
            self.run_stats_async(show_success=False)

    def _clear_shift_selection(self, _event: ft.ControlEvent) -> None:
        self.selected_shifts = []
        self._refresh_filter_fields()
        self.page.update()
        if self.selected_files or self.selected_uploads:
            self.run_stats_async(show_success=False)

    def _refresh_name_selector(self) -> None:
        self._refresh_selector_panel(
            self.name_input,
            self._available_name_options(),
            self.selected_names,
            self.name_search_keyword,
            self._on_name_search_change,
            self._on_name_checkbox_change,
            self._select_all_names,
            self._clear_name_selection,
        )

    def _refresh_workno_selector(self) -> None:
        self._refresh_selector_panel(
            self.workno_input,
            self._available_workno_options(),
            self.selected_worknos,
            self.workno_search_keyword,
            self._on_workno_search_change,
            self._on_workno_checkbox_change,
            self._select_all_worknos,
            self._clear_workno_selection,
        )

    def _refresh_shift_selector(self) -> None:
        self._refresh_selector_panel(
            self.shift_input,
            self._available_shift_options(),
            self.selected_shifts,
            self.shift_search_keyword,
            self._on_shift_search_change,
            self._on_shift_checkbox_change,
            self._select_all_shifts,
            self._clear_shift_selection,
        )

    def _build_view(self) -> None:
        title_block = ft.Container(
            padding=ft.Padding.all(20),
            border_radius=24,
            gradient=ft.LinearGradient(
                begin=ft.Alignment(-1, -1),
                end=ft.Alignment(1, 1),
                colors=["#133c55", "#1f7a8c", "#7cc6fe"],
            ),
            content=ft.Row(
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                vertical_alignment=ft.CrossAxisAlignment.START,
                controls=[
                    ft.Column(
                        spacing=6,
                        expand=True,
                        controls=[
                            ft.Text("人员出入车间时长统计", size=28, weight=ft.FontWeight.BOLD, color="#ffffff"),
                            ft.Text("作者：ghwg", size=13, weight=ft.FontWeight.W_600, color="#d9f2ff"),
                            ft.Text(
                                "导入门禁 Excel 后，自动识别人员主车间区域和班次，计算单次、当日、当周、当月在车间时长。",
                                size=14,
                                color="#e7f5ff",
                            ),
                        ],
                    ),
                    self.license_manage_button,
                ],
            ),
        )

        filter_card = ft.Container(
            margin=ft.Margin.only(top=14),
            padding=ft.Padding.all(18),
            border_radius=24,
            bgcolor="#fdfdfd",
            content=ft.Column(
                spacing=14,
                controls=[
                    ft.Text("筛选条件", size=18, weight=ft.FontWeight.W_600, color="#102a43"),
                    ft.ResponsiveRow(
                        controls=[
                            self.shift_input,
                            self.name_input,
                            self.workno_input,
                            self.start_date_field,
                            self.start_time_field,
                            self.end_date_field,
                            self.end_time_field,
                            self.duplicate_input,
                        ]
                    ),
                    ft.Row(
                        wrap=True,
                        spacing=10,
                        controls=[
                            self._action_button("今天", ft.Icons.TODAY, self.apply_today_filter, "#0f766e"),
                            self._action_button("昨天", ft.Icons.HISTORY, self.apply_yesterday_filter, "#0f766e"),
                            self._action_button("本周", ft.Icons.DATE_RANGE, self.apply_current_week_filter, "#145da0"),
                            self._action_button("本月", ft.Icons.CALENDAR_MONTH, self.apply_current_month_filter, "#7a3e00"),
                        ],
                    ),
                    ft.Row(
                        wrap=True,
                        spacing=10,
                        controls=[
                            self._action_button("选择文件", ft.Icons.UPLOAD_FILE, self.pick_files, "#0b6e4f"),
                            self._action_button("重新统计", ft.Icons.ANALYTICS, self.run_stats, "#145da0"),
                            self._action_button("导出结果", ft.Icons.FILE_DOWNLOAD, self.export_current_result, "#7a3e00"),
                            self._action_button("清空筛选", ft.Icons.FILTER_ALT_OFF, self.clear_filters, "#6b7280"),
                        ],
                    ),
                    self.file_text,
                    self.range_text,
                    self.summary_text,
                    self.loading_indicator,
                ],
            ),
        )

        result_card = ft.Container(
            margin=ft.Margin.only(top=16),
            padding=ft.Padding.all(18),
            border_radius=24,
            bgcolor="#ffffff",
            expand=True,
            content=ft.Column(
                expand=True,
                spacing=14,
                controls=[
                    self.tab_bar,
                    ft.Divider(height=1, color="#dbe2ea"),
                    self.tab_loading_indicator,
                    ft.Stack(
                        expand=True,
                        controls=[
                            self.tables_column,
                            self.table_loading_overlay,
                        ],
                    ),
                ],
            ),
        )

        self.page.add(title_block, filter_card, result_card)

    def _action_button(self, text: str, icon: str, on_click, color: str) -> ft.Container:
        return ft.Container(
            content=ft.Button(
                content=text,
                icon=icon,
                on_click=on_click,
                style=ft.ButtonStyle(
                    color="#ffffff",
                    bgcolor=color,
                    padding=ft.Padding.symmetric(horizontal=20, vertical=16),
                    shape=ft.RoundedRectangleBorder(radius=14),
                ),
            ),
        )

    async def pick_files(self, _=None) -> None:
        if not self.ensure_license_active():
            return
        files = await self.file_picker.pick_files(
            dialog_title="选择门禁 Excel 或 ZIP 文件",
            allowed_extensions=["xlsx", "xls", "xlsm", "zip"],
            allow_multiple=True,
            with_data=True,
        )
        if not files:
            self.selected_files = []
            self.selected_uploads = []
            self.reset_when_no_files()
            return
        uploads: list[InMemoryFile] = []
        file_names: list[str] = []
        local_paths: list[str] = []
        for file in files:
            if getattr(file, "path", None):
                local_paths.append(file.path)
                file_names.append(Path(file.path).name)
            elif getattr(file, "bytes", None):
                uploads.append(InMemoryFile(name=file.name, content=file.bytes))
                file_names.append(file.name)

        self.selected_files = local_paths
        self.selected_uploads = uploads
        if not self.selected_files and not self.selected_uploads:
            self.reset_when_no_files()
            self.show_error("没有读取到可用文件，请重新选择。")
            return
        self.file_text.value = f"已选择 {len(file_names)} 个文件: {'；'.join(file_names)}"
        self.load_profile_and_refresh()

    def reset_when_no_files(self) -> None:
        self.file_text.value = "未选择文件"
        self.range_text.value = ""
        self.summary_text.value = "请先导入 Excel 或 ZIP 文件。"
        self.current_page = 1
        if self.page_jump_field is not None:
            self.page_jump_field.value = ""
        self.selected_names = []
        self.selected_worknos = []
        self.selected_shifts = []
        self.profile = None
        self.result = None
        self.loading_indicator.visible = False
        self.tab_loading_indicator.visible = False
        self.table_loading_overlay.visible = False
        self._is_loading = False
        self._reset_table_drag_state()
        self._refresh_filter_fields()
        self.tables_column.controls = [
            ft.Container(
                padding=ft.Padding.all(30),
                content=ft.Text("当前没有已加载文件，请先选择文件。", color="#52606d"),
            )
        ]
        self.page.update()

    def load_profile_and_refresh(self) -> None:
        if not self.selected_files and not self.selected_uploads:
            self.reset_when_no_files()
            return

        try:
            self.result = None
            self.profile = build_data_profile(paths=self.selected_files, files=self.selected_uploads)
            self.selected_names = []
            self.selected_worknos = []
            self.selected_shifts = []
            self.name_search_keyword = ""
            self.workno_search_keyword = ""
            self.shift_search_keyword = ""
            self._sync_filter_selections()
            if self.selected_files:
                self._refresh_file_label()
            self._refresh_range_text()
            self.run_stats_async(show_success=False)
        except Exception as exc:  # noqa: BLE001
            self.show_error(f"加载文件失败: {exc}")

    def _refresh_filter_hints(self) -> None:
        if self.profile is None:
            self.name_input.data["helper"].value = "点击选择，可多选"
            self.workno_input.data["helper"].value = "点击选择，可多选"
            return

        self.name_input.data["helper"].value = (
            f"已加载 {len(self.profile.names)} 个姓名；展开后可勾选"
        )
        self.workno_input.data["helper"].value = (
            f"已加载 {len(self.profile.worknos)} 个工号；展开后可勾选"
        )
        self.shift_input.data["helper"].value = (
            f"已加载 {len(self.profile.shifts)} 个班次；展开后可勾选"
        )

    def _refresh_file_label(self) -> None:
        names = "；".join(Path(item).name for item in self.selected_files)
        self.file_text.value = f"已选择 {len(self.selected_files)} 个文件: {names}"

    def _refresh_range_text(self) -> None:
        if self.profile is None or self.profile.min_time is None or self.profile.max_time is None:
            self.range_text.value = ""
            return
        self.range_text.value = (
            f"当前数据范围: {format_dt(self.profile.min_time)} 至 {format_dt(self.profile.max_time)}"
        )

    def _current_start_text(self) -> str:
        if not self.start_filter_enabled:
            return ""
        date_text = self.start_date_field.value.strip()
        if not date_text:
            return ""
        time_text = self.start_time_field.value.strip() or "00:00:00"
        return f"{date_text} {time_text}"

    def _current_end_text(self) -> str:
        if not self.end_filter_enabled:
            return ""
        date_text = self.end_date_field.value.strip()
        if not date_text:
            return ""
        time_text = self.end_time_field.value.strip() or "23:59:59"
        return f"{date_text} {time_text}"

    def set_date_range_filter(self, start_dt: datetime, end_dt: datetime) -> None:
        self.start_filter_enabled = True
        self.end_filter_enabled = True
        self.start_date_picker.value = start_dt.date()
        self.end_date_picker.value = end_dt.date()
        self.start_time_picker.value = start_dt.time().replace(microsecond=0)
        self.end_time_picker.value = end_dt.time().replace(microsecond=0)
        self.start_date_field.value = start_dt.date().isoformat()
        self.end_date_field.value = end_dt.date().isoformat()
        self.start_time_field.value = start_dt.strftime("%H:%M:%S")
        self.end_time_field.value = end_dt.strftime("%H:%M:%S")

    def apply_today_filter(self, _=None) -> None:
        today = datetime.now().date()
        self.set_date_range_filter(
            datetime.combine(today, time(0, 0, 0)),
            datetime.combine(today, time(23, 59, 59)),
        )
        self.page.update()
        self.run_stats_async(show_success=False)

    def apply_yesterday_filter(self, _=None) -> None:
        target_day = datetime.now().date() - timedelta(days=1)
        self.set_date_range_filter(
            datetime.combine(target_day, time(0, 0, 0)),
            datetime.combine(target_day, time(23, 59, 59)),
        )
        self.page.update()
        self.run_stats_async(show_success=False)

    def apply_current_week_filter(self, _=None) -> None:
        today = pd.Timestamp(datetime.now().date())
        week_start, week_end = calculate_week_range(today)
        self.set_date_range_filter(
            datetime.combine(week_start.date(), time(0, 0, 0)),
            datetime.combine(week_end.date(), time(23, 59, 59)),
        )
        self.page.update()
        self.run_stats_async(show_success=False)

    def apply_current_month_filter(self, _=None) -> None:
        now = datetime.now()
        month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        if month_start.month == 12:
            next_month_start = month_start.replace(year=month_start.year + 1, month=1)
        else:
            next_month_start = month_start.replace(month=month_start.month + 1)
        month_end = next_month_start - timedelta(seconds=1)
        self.set_date_range_filter(month_start, month_end)
        self.page.update()
        self.run_stats_async(show_success=False)

    def run_stats(self, _=None) -> None:
        self.run_stats_async(show_success=True)

    def run_stats_async(self, show_success: bool = True) -> None:
        if not self.ensure_license_active():
            return
        if not self.selected_files and not self.selected_uploads:
            self.reset_when_no_files()
            self.show_error("请先选择至少一个 Excel 或 ZIP 文件。")
            return
        if self._is_loading:
            return

        self._is_loading = True
        self.loading_indicator.visible = True
        self.summary_text.value = "正在统计，请稍候..."
        self._reset_table_drag_state()
        self.tables_column.controls = [
            ft.Container(
                padding=ft.Padding.all(30),
                content=ft.Column(
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.ProgressRing(width=32, height=32, stroke_width=3),
                        ft.Text("正在加载进出车间记录...", color="#52606d"),
                    ],
                ),
            )
        ]
        self.page.update()

        self.page.run_thread(self._run_stats_worker, show_success)

    def _run_stats_worker(self, show_success: bool) -> None:
        try:
            duplicate_seconds = int((self.duplicate_input.value or str(DEFAULT_DUPLICATE_SECONDS)).strip())
            if duplicate_seconds < 0:
                raise ValueError("去重秒数不能为负数。")

            result = generate_stats(
                paths=self.selected_files,
                files=self.selected_uploads,
                name_keyword=",".join(self.selected_names),
                workno_keyword=",".join(self.selected_worknos),
                shift_keyword=",".join(self.selected_shifts),
                start_text=self._current_start_text(),
                end_text=self._current_end_text(),
                duplicate_seconds=duplicate_seconds,
            )
            self.page.run_task(self._apply_stats_result, result, show_success)
        except Exception as exc:  # noqa: BLE001
            self.page.run_task(self._handle_stats_error, str(exc))

    def clear_filters(self, _=None) -> None:
        self.selected_names = []
        self.selected_worknos = []
        self.selected_shifts = []
        self._refresh_filter_fields()
        now = datetime.now()
        self.start_date_field.value = ""
        self.start_time_field.value = ""
        self.end_date_field.value = ""
        self.end_time_field.value = ""
        self.start_date_picker.value = now.date()
        self.end_date_picker.value = now.date()
        self.start_time_picker.value = now.time().replace(microsecond=0)
        self.end_time_picker.value = time(23, 59, 59)
        self.start_filter_enabled = False
        self.end_filter_enabled = False
        self.duplicate_input.value = str(DEFAULT_DUPLICATE_SECONDS)
        if self.selected_files or self.selected_uploads:
            self.run_stats_async(show_success=False)
        else:
            self.reset_when_no_files()

    async def export_current_result(self, _=None) -> None:
        if not self.ensure_license_active():
            return
        if self.result is None:
            self.show_export_result_dialog(
                title="无法导出",
                message="请先完成统计后再导出结果。",
                success=False,
            )
            return

        if self.page.web:
            self.show_export_result_dialog(
                title="无法导出",
                message="当前是浏览器模式，不能直接导出到程序目录。请使用桌面模式或打包后的 EXE 运行后再导出。",
                success=False,
            )
            return

        try:
            output_name = f"车间时长统计_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            output_dir = get_export_base_dir() / "导出数据"
            output_dir.mkdir(parents=True, exist_ok=True)
            output_path = output_dir / output_name
            export_result(self.result, output_path)
            self.show_export_result_dialog(
                title="导出完成",
                message="统计结果已经成功导出。",
                output_path=output_path,
                success=True,
            )
        except Exception as exc:  # noqa: BLE001
            self.show_export_result_dialog(
                title="导出失败",
                message=f"导出结果时出现异常：{exc}",
                success=False,
            )

    def _table_for_index(self, index: int) -> pd.DataFrame:
        if self.result is None:
            return pd.DataFrame()
        table_map = {
            0: self.result.detail_sheet,
            1: self.result.daily_sheet,
            2: self.result.weekly_sheet,
            3: self.result.monthly_sheet,
            4: self.result.primary_areas,
        }
        return table_map.get(index, pd.DataFrame())

    def _render_active_tab(self) -> None:
        dataframe = self._table_for_index(self.active_tab_index)
        self._refresh_tab_buttons()
        self.tables_column.controls = [self._build_dataframe_view(dataframe)]

    def _show_tab_loading_state(self) -> None:
        self.tab_loading_indicator.visible = True
        self.table_loading_overlay.visible = True
        self.tables_column.controls = [
            ft.Container(
                padding=ft.Padding.all(30),
                content=ft.Column(
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.ProgressRing(width=32, height=32, stroke_width=3),
                        ft.Text("正在切换并加载当前标签页数据...", color="#52606d"),
                    ],
                ),
            )
        ]

    async def _render_active_tab_async(self) -> None:
        try:
            self._render_active_tab()
        finally:
            self.tab_loading_indicator.visible = False
            self.table_loading_overlay.visible = False
            self.page.update()

    def _total_pages_for_frame(self, frame: pd.DataFrame) -> int:
        if frame.empty:
            return 1
        return max((len(frame) + self.page_size - 1) // self.page_size, 1)

    def _current_page_slice(self, frame: pd.DataFrame) -> tuple[pd.DataFrame, int, int]:
        total_pages = self._total_pages_for_frame(frame)
        self.current_page = min(max(self.current_page, 1), total_pages)
        start_index = (self.current_page - 1) * self.page_size
        end_index = start_index + self.page_size
        return frame.iloc[start_index:end_index].copy(), start_index, total_pages

    def _reset_table_drag_state(self) -> None:
        self._table_scroll_row = None
        self._table_drag_surface = None
        self._table_horizontal_pixels = 0.0
        self._table_max_horizontal_scroll = 0.0
        self._table_pending_scroll_target = None
        self._table_scroll_task_running = False
        self._table_is_dragging = False

    def _on_table_scroll(self, event: ft.OnScrollEvent) -> None:
        self._table_horizontal_pixels = max(float(event.pixels or 0), 0.0)
        self._table_max_horizontal_scroll = max(float(event.max_scroll_extent or 0), 0.0)

    def _set_table_drag_cursor(self, cursor: ft.MouseCursor) -> None:
        if self._table_drag_surface is None:
            return
        self._table_drag_surface.mouse_cursor = cursor
        self._table_drag_surface.update()

    def _on_table_drag_start(self, _event: ft.DragStartEvent) -> None:
        self._table_is_dragging = True
        self._set_table_drag_cursor(ft.MouseCursor.GRABBING)

    def _on_table_drag_end(self, _event: ft.DragEndEvent) -> None:
        self._table_is_dragging = False
        self._set_table_drag_cursor(ft.MouseCursor.GRAB)

    def _on_table_drag_cancel(self, _event: ft.ControlEvent) -> None:
        self._table_is_dragging = False
        self._set_table_drag_cursor(ft.MouseCursor.GRAB)

    def _on_table_horizontal_drag_update(self, event: ft.DragUpdateEvent) -> None:
        if self._table_scroll_row is None or event.primary_delta is None:
            return
        delta = -float(event.primary_delta)
        if abs(delta) < 0.5:
            return

        target = self._table_horizontal_pixels + delta
        if self._table_max_horizontal_scroll > 0:
            target = min(max(target, 0.0), self._table_max_horizontal_scroll)
        else:
            target = max(target, 0.0)

        self._table_pending_scroll_target = target
        self._table_horizontal_pixels = target
        if not self._table_scroll_task_running:
            self._table_scroll_task_running = True
            self.page.run_task(self._flush_table_horizontal_scroll)

    async def _flush_table_horizontal_scroll(self) -> None:
        try:
            while self._table_scroll_row is not None and self._table_pending_scroll_target is not None:
                if getattr(self.page, "session", None) is None:
                    self._table_pending_scroll_target = None
                    break
                target = self._table_pending_scroll_target
                self._table_pending_scroll_target = None
                try:
                    await self._table_scroll_row.scroll_to(offset=target, duration=0)
                except RuntimeError as exc:
                    if "Session closed" in str(exc):
                        self._table_pending_scroll_target = None
                        break
                    raise
                if self._table_is_dragging:
                    await asyncio.sleep(1 / 60)
        finally:
            self._table_scroll_task_running = False

    def _build_dataframe_view(self, dataframe: pd.DataFrame) -> ft.Control:
        if dataframe.empty:
            return ft.Container(
                padding=ft.Padding.all(30),
                content=ft.Text("当前筛选条件下没有可显示的数据。", color="#52606d"),
            )

        frame = dataframe.copy()
        for column in frame.columns:
            if pd.api.types.is_datetime64_any_dtype(frame[column]):
                if "日期" in str(column) and "时间" not in str(column):
                    frame[column] = frame[column].dt.strftime("%Y-%m-%d")
                else:
                    frame[column] = frame[column].dt.strftime("%Y-%m-%d %H:%M:%S")
        frame = frame.fillna("")
        preview, start_index, total_pages = self._current_page_slice(frame)
        cell_widths = {
            "人员姓名": 100,
            "工号": 100,
            "班次": 70,
            "主车间区域": 260,
            "统计日期": 110,
            "周开始日期": 110,
            "周结束日期": 110,
            "统计月份": 100,
            "进车间时间": 150,
            "出车间时间": 150,
            "单次在车间时长": 110,
            "当天在车间时长": 110,
            "当周在车间时长": 110,
            "当月在车间时长": 110,
            "进门禁点": 160,
            "出门禁点": 160,
            "进记录来源": 220,
            "出记录来源": 220,
        }

        def build_cell(value: object, column_name: str, is_header: bool = False) -> ft.Container:
            width = cell_widths.get(column_name, 140)
            return ft.Container(
                width=width,
                padding=ft.Padding.symmetric(vertical=8, horizontal=8),
                border=ft.Border(
                    right=ft.BorderSide(1, "#d9e2ec"),
                    bottom=ft.BorderSide(1, "#d9e2ec"),
                ),
                bgcolor="#d9eefc" if is_header else "#ffffff",
                content=ft.Text(
                    str(column_name) if is_header else safe_text(value),
                    size=12,
                    weight=ft.FontWeight.W_700 if is_header else ft.FontWeight.W_400,
                    color="#102a43" if is_header else "#243b53",
                    no_wrap=False,
                    selectable=True,
                ),
            )

        header_row = ft.Row(
            spacing=0,
            controls=[build_cell(None, str(column), is_header=True) for column in frame.columns],
        )
        data_rows: list[ft.Control] = [header_row]
        for row_index, row in enumerate(preview.itertuples(index=False, name=None)):
            row_bg = "#ffffff" if row_index % 2 == 0 else "#f8fbff"
            cells = []
            for column_name, value in zip(frame.columns, row):
                width = cell_widths.get(str(column_name), 140)
                cells.append(
                    ft.Container(
                        width=width,
                        padding=ft.Padding.symmetric(vertical=8, horizontal=8),
                        border=ft.Border(
                            right=ft.BorderSide(1, "#d9e2ec"),
                            bottom=ft.BorderSide(1, "#d9e2ec"),
                        ),
                        bgcolor=row_bg,
                        content=ft.Text(
                            safe_text(value),
                            size=12,
                            color="#243b53",
                            no_wrap=False,
                            selectable=True,
                        ),
                    )
                )
            data_rows.append(ft.Row(spacing=0, controls=cells))

        helper_text = (
            f"当前显示第 {self.current_page} / {total_pages} 页，本页 {len(preview)} 条，共 {len(frame)} 条。导出结果会保留完整数据。"
        )
        if self.pagination_summary_text is not None:
            self.pagination_summary_text.value = helper_text
        if self.page_jump_field is not None:
            self.page_jump_field.hint_text = f"1 - {total_pages}"
        self._reset_table_drag_state()
        table_content = ft.Column(
            spacing=0,
            controls=data_rows,
            tight=True,
        )
        table_view = ft.Row(
            scroll=ft.Scrollbar(
                thumb_visibility=True,
                track_visibility=True,
                interactive=True,
                orientation=ft.ScrollbarOrientation.BOTTOM,
                thickness=10,
            ),
            on_scroll=self._on_table_scroll,
            expand=True,
            controls=[
                ft.Container(
                    border=ft.Border.all(1, "#d9e2ec"),
                    border_radius=14,
                    clip_behavior=ft.ClipBehavior.HARD_EDGE,
                    content=table_content,
                )
            ],
        )
        self._table_scroll_row = table_view
        drag_surface = ft.GestureDetector(
            expand=True,
            mouse_cursor=ft.MouseCursor.GRAB,
            on_horizontal_drag_start=self._on_table_drag_start,
            on_horizontal_drag_update=self._on_table_horizontal_drag_update,
            on_horizontal_drag_end=self._on_table_drag_end,
            on_horizontal_drag_cancel=self._on_table_drag_cancel,
            content=table_view,
        )
        self._table_drag_surface = drag_surface
        return ft.Column(
            expand=True,
            controls=[
                self._build_pagination_bar(total_pages, len(frame), start_index, len(preview)),
                ft.Text(
                    "可在数据表区域按住鼠标左右拖拽，快速浏览首尾列。",
                    size=11,
                    color="#7b8794",
                ),
                ft.Container(
                    expand=True,
                    border=ft.Border.all(1, "#d9e2ec"),
                    border_radius=18,
                    bgcolor="#fbfdff",
                    padding=ft.Padding.all(8),
                    content=drag_surface,
                ),
                self._build_pagination_bar(total_pages, len(frame), start_index, len(preview)),
            ],
        )

    def _build_pagination_bar(self, total_pages: int, total_rows: int, start_index: int, current_count: int) -> ft.Control:
        end_index = start_index + current_count
        page_jump_field = ft.TextField(
            label="跳转页码",
            width=120,
            dense=True,
            filled=True,
            border_radius=14,
            bgcolor="#ffffff",
            keyboard_type=ft.KeyboardType.NUMBER,
            hint_text=f"1 - {total_pages}",
            on_submit=self._jump_to_page,
        )
        jump_button = ft.OutlinedButton("跳转", on_click=self._jump_to_page)
        page_jump_field.data = jump_button
        jump_button.data = page_jump_field
        return ft.ResponsiveRow(
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                ft.Container(
                    col={"xs": 12, "md": 5},
                    content=ft.Text(
                        f"当前第 {self.current_page} / {total_pages} 页，显示第 {start_index + 1 if total_rows else 0}-{end_index} 条，共 {total_rows} 条。",
                        size=12,
                        color="#52606d",
                    ),
                ),
                ft.Container(
                    col={"xs": 12, "md": 7},
                    content=ft.Row(
                        wrap=True,
                        alignment=ft.MainAxisAlignment.END,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=8,
                        controls=[
                            self.page_size_dropdown,
                            page_jump_field,
                            jump_button,
                            ft.OutlinedButton("上一页", on_click=self._go_prev_page, disabled=self.current_page <= 1),
                            ft.OutlinedButton("下一页", on_click=self._go_next_page, disabled=self.current_page >= total_pages),
                        ],
                    ),
                ),
            ],
        )

    def switch_tab(self, index: int) -> None:
        if self.result is None:
            return
        if self.active_tab_index == index:
            return
        self.active_tab_index = index
        self.current_page = 1
        if self.page_jump_field is not None:
            self.page_jump_field.value = ""
        self._show_tab_loading_state()
        self.page.update()
        self.page.run_task(self._render_active_tab_async)

    def _on_page_size_change(self, event: ft.ControlEvent) -> None:
        try:
            self.page_size = max(int(str(event.control.value or "50").strip()), 1)
        except ValueError:
            self.page_size = 50
        self.current_page = 1
        if self.result is not None:
            self._show_tab_loading_state()
            self.page.update()
            self.page.run_task(self._render_active_tab_async)

    def _go_prev_page(self, _=None) -> None:
        if self.result is None or self.current_page <= 1:
            return
        self.current_page -= 1
        self._show_tab_loading_state()
        self.page.update()
        self.page.run_task(self._render_active_tab_async)

    def _go_next_page(self, _=None) -> None:
        if self.result is None:
            return
        total_pages = self._total_pages_for_frame(self._table_for_index(self.active_tab_index))
        if self.current_page >= total_pages:
            return
        self.current_page += 1
        self._show_tab_loading_state()
        self.page.update()
        self.page.run_task(self._render_active_tab_async)

    def _jump_to_page(self, _=None) -> None:
        if self.result is None:
            return
        source = getattr(_, "control", None) if _ is not None else None
        page_jump_field = None
        if isinstance(source, ft.TextField):
            page_jump_field = source
        else:
            candidate = getattr(source, "data", None) if source is not None else None
            if isinstance(candidate, ft.TextField):
                page_jump_field = candidate
        if page_jump_field is None:
            page_jump_field = self.page_jump_field
        if page_jump_field is None:
            return

        raw_value = (page_jump_field.value or "").strip()
        if not raw_value:
            return
        try:
            target_page = int(raw_value)
        except ValueError:
            self.show_error("跳转页码必须是数字。")
            return
        total_pages = self._total_pages_for_frame(self._table_for_index(self.active_tab_index))
        self.current_page = min(max(target_page, 1), total_pages)
        self._show_tab_loading_state()
        self.page.update()
        self.page.run_task(self._render_active_tab_async)

    def _refresh_tab_buttons(self) -> None:
        active_bg = "#145da0"
        inactive_bg = "#ffffff"
        active_fg = "#ffffff"
        inactive_fg = "#243b53"
        for index, control in enumerate(self.tab_bar.controls):
            control.style = ft.ButtonStyle(
                color=active_fg if index == self.active_tab_index else inactive_fg,
                bgcolor=active_bg if index == self.active_tab_index else inactive_bg,
                side=ft.BorderSide(1, "#145da0"),
                shape=ft.RoundedRectangleBorder(radius=999),
                padding=ft.Padding.symmetric(horizontal=18, vertical=14),
            )

    def open_start_date_picker(self, _=None) -> None:
        self.start_date_picker.open = True
        self.page.update()

    def open_end_date_picker(self, _=None) -> None:
        self.end_date_picker.open = True
        self.page.update()

    def open_start_time_picker(self, _=None) -> None:
        self.start_time_picker.open = True
        self.page.update()

    def open_end_time_picker(self, _=None) -> None:
        self.end_time_picker.open = True
        self.page.update()

    def _on_start_date_change(self, event: ft.ControlEvent) -> None:
        value = event.control.value
        self.start_date_field.value = format_date_only(value)
        self.start_time_picker.value = time(0, 0, 0)
        self.start_time_field.value = "00:00:00"
        self.start_filter_enabled = True
        self.end_date_picker.value = value
        self.end_time_picker.value = time(23, 59, 59)
        self.end_date_field.value = format_date_only(value)
        self.end_time_field.value = "23:59:59"
        self.end_filter_enabled = True
        self.page.update()
        self.run_stats_async(show_success=False)

    def _on_end_date_change(self, event: ft.ControlEvent) -> None:
        value = event.control.value
        self.end_date_field.value = format_date_only(value)
        self.end_time_picker.value = time(23, 59, 59)
        self.end_time_field.value = "23:59:59"
        self.end_filter_enabled = True
        self.page.update()
        self.run_stats_async(show_success=False)

    def _on_start_time_change(self, event: ft.ControlEvent) -> None:
        value = event.control.value
        if isinstance(value, time):
            self.start_time_field.value = value.strftime("%H:%M:%S")
            if not self.start_date_field.value:
                self.start_date_field.value = format_date_only(self.start_date_picker.value or datetime.now().date())
            self.start_filter_enabled = True
            self.page.update()
            self.run_stats_async(show_success=False)

    def _on_end_time_change(self, event: ft.ControlEvent) -> None:
        value = event.control.value
        if isinstance(value, time):
            self.end_time_field.value = value.strftime("%H:%M:%S")
            if not self.end_date_field.value:
                self.end_date_field.value = format_date_only(self.end_date_picker.value or datetime.now().date())
            self.end_filter_enabled = True
            self.page.update()
            self.run_stats_async(show_success=False)

    async def _apply_stats_result(self, result, show_success: bool) -> None:
        self.result = result
        self.current_page = 1
        if self.page_jump_field is not None:
            self.page_jump_field.value = ""
        self._is_loading = False
        self.loading_indicator.visible = False
        self.tab_loading_indicator.visible = False
        self.table_loading_overlay.visible = False
        self.summary_text.value = summarize_result(self.result)
        self._render_active_tab()
        self.page.update()
        if show_success:
            self.show_info("统计完成，结果已更新。")

    async def _handle_stats_error(self, message: str) -> None:
        self._is_loading = False
        self.loading_indicator.visible = False
        self.tab_loading_indicator.visible = False
        self.table_loading_overlay.visible = False
        self.summary_text.value = "统计失败"
        self.page.update()
        self.show_error(f"统计失败: {message}")

    def show_error(self, message: str) -> None:
        self.page.show_dialog(
            ft.SnackBar(
                content=ft.Text(message, color="#ffffff"),
                bgcolor="#b42318",
                behavior=ft.SnackBarBehavior.FLOATING,
                show_close_icon=True,
                duration=3500,
                open=True,
            )
        )
        self.page.update()

    def show_info(self, message: str) -> None:
        self.page.show_dialog(
            ft.SnackBar(
                content=ft.Text(message, color="#ffffff"),
                bgcolor="#0b6e4f",
                behavior=ft.SnackBarBehavior.FLOATING,
                show_close_icon=True,
                duration=2500,
                open=True,
            )
        )
        self.page.update()

    def close_dialog(self, _=None) -> None:
        self.page.pop_dialog()

    def open_export_directory(self, output_path: Path) -> None:
        target_dir = output_path.parent
        try:
            os.startfile(str(target_dir))
        except Exception as exc:  # noqa: BLE001
            self.show_error(f"打开导出目录失败：{exc}")

    def show_export_result_dialog(
        self,
        title: str,
        message: str,
        output_path: Path | None = None,
        success: bool = True,
    ) -> None:
        resolved_path = str(output_path.resolve()) if output_path is not None else ""
        accent_color = "#0b6e4f" if success else "#b42318"
        icon_name = ft.Icons.CHECK_CIRCLE if success else ft.Icons.ERROR_OUTLINE
        content_controls: list[ft.Control] = [
            ft.Row(
                spacing=12,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Icon(icon_name, color=accent_color, size=28),
                    ft.Container(
                        expand=True,
                        content=ft.Text(message, size=14, color="#1f2937"),
                    ),
                ],
            )
        ]
        if resolved_path:
            content_controls.extend(
                [
                    ft.Text("导出位置：", weight=ft.FontWeight.W_600),
                    ft.Container(
                        content=ft.Text(resolved_path, size=13, color="#1f2937"),
                        padding=12,
                        border_radius=10,
                        bgcolor="#f3f4f6",
                    ),
                ]
            )

        actions: list[ft.Control] = []
        if success and output_path is not None:
            actions.append(
                ft.TextButton(
                    "打开导出目录",
                    on_click=lambda _: self.open_export_directory(output_path),
                )
            )
        actions.append(ft.TextButton("确定", on_click=self.close_dialog))

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text(title),
            content=ft.Column(
                controls=content_controls,
                tight=True,
            ),
            actions=actions,
            actions_alignment=ft.MainAxisAlignment.END,
        )
        self.page.show_dialog(dialog)


def main(page: ft.Page) -> None:
    WorkshopStatsFletApp(page)


def run_app() -> None:
    force_mode = ""
    is_packaged = getattr(sys, "frozen", False)
    if "--web" in sys.argv:
        force_mode = "web"
    elif "--desktop" in sys.argv:
        force_mode = "desktop"
    else:
        force_mode = os.getenv("WORKSHOP_APP_VIEW", "").strip().lower()

    if force_mode == "web":
        ft.run(main, view=ft.AppView.WEB_BROWSER)
        return

    if force_mode == "desktop":
        ft.run(main, view=ft.AppView.FLET_APP)
        return

    try:
        ft.run(main, view=ft.AppView.FLET_APP)
    except Exception as exc:  # noqa: BLE001
        message = str(exc)
        desktop_prepare_failed = any(
            keyword in message
            for keyword in (
                "Remote end closed connection",
                "flet_desktop",
                "urlretrieve",
                "Preparing Flet",
            )
        )
        if not desktop_prepare_failed:
            raise

        if is_packaged:
            raise RuntimeError(
                "当前 EXE 未内置 Flet 桌面运行时，启动时仍尝试联网下载客户端。\n"
                "请改用 Flet 官方构建流程重新打包离线桌面应用。"
            ) from exc

        print(
            "Flet 桌面客户端首次准备失败，已自动切换为浏览器模式。\n"
            "如果你想使用桌面窗口，请在网络可用时先成功启动一次，"
            "或者后续直接使用 Flet 官方构建流程打包。"
        )
        ft.run(main, view=ft.AppView.WEB_BROWSER)


if __name__ == "__main__":
    run_app()
