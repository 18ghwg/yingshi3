from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
import math
from pathlib import Path
from typing import Sequence
import re
import warnings
import zipfile

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side


REQUIRED_COLUMNS = [
    "人员姓名",
    "工号",
    "门禁点",
    "门禁点区域",
    "出/入",
    "事件时间",
]

TURNSTILE_KEYWORDS = ("三棍闸", "三辊闸")
WORKSHOP_KEYWORD = "更衣室"
DEFAULT_DUPLICATE_SECONDS = 90
DAY_SHIFT_NAME = "白班"
NIGHT_SHIFT_NAME = "夜班"
NIGHT_SHIFT_LATE_START_HOUR = 20
NIGHT_SHIFT_EARLY_START_HOUR = 6
NIGHT_SHIFT_END_HOUR = 8
SHIFT_BLOCK_BREAK_HOURS = 8

warnings.filterwarnings(
    "ignore",
    message="Workbook contains no default style, apply openpyxl's default",
    category=UserWarning,
)


@dataclass
class StatsResult:
    raw_events: pd.DataFrame
    primary_areas: pd.DataFrame
    sessions: pd.DataFrame
    detail_sheet: pd.DataFrame
    daily_sheet: pd.DataFrame
    weekly_sheet: pd.DataFrame
    monthly_sheet: pd.DataFrame
    filter_summary: str = ""


@dataclass
class DataProfile:
    names: list[str]
    worknos: list[str]
    shifts: list[str]
    min_time: pd.Timestamp | None
    max_time: pd.Timestamp | None


@dataclass
class InMemoryFile:
    name: str
    content: bytes


def normalize_text(value: object) -> str:
    if pd.isna(value):
        return ""
    text = str(value)
    return text.replace("\t", "").replace("\r", "").replace("\n", "").strip()


def normalize_workno(value: object) -> str:
    text = normalize_text(value)
    return text.strip("'")


def split_filter_values(value: str) -> list[str]:
    if pd.isna(value):
        return []
    text = str(value).replace("\t", " ").replace("\r", "\n")
    parts = re.split(r"[\s,，;；]+", text)
    return [part for part in (normalize_text(item) for item in parts) if part]


def normalize_direction(direction: object, door_name: object) -> str:
    raw_direction = normalize_text(direction)
    if raw_direction.startswith("入") or raw_direction == "进":
        return "入"
    if raw_direction.startswith("出"):
        return "出"

    door_text = normalize_text(door_name)
    if "出" in door_text and "进" not in door_text:
        return "出"
    if "进" in door_text and "出" not in door_text:
        return "入"
    if door_text.endswith("-出"):
        return "出"
    if door_text.endswith("-进"):
        return "入"
    return raw_direction


def is_turnstile_area(area: str) -> bool:
    return any(keyword in area for keyword in TURNSTILE_KEYWORDS)


def is_candidate_workshop_area(area: str) -> bool:
    return WORKSHOP_KEYWORD in area and not is_turnstile_area(area)


def parse_filter_datetime(value: str, is_end: bool = False) -> pd.Timestamp | None:
    text = normalize_text(value)
    if not text:
        return None

    parsed = pd.to_datetime(text, errors="coerce")
    if pd.isna(parsed):
        raise ValueError(f"无法识别时间格式: {text}")

    if len(text) <= 10 and is_end:
        return parsed + pd.Timedelta(days=1) - pd.Timedelta(seconds=1)
    return parsed


def format_duration(seconds: float | int | None) -> str:
    if seconds is None or pd.isna(seconds):
        return ""
    total_seconds = max(int(round(float(seconds))), 0)
    hours, remainder = divmod(total_seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


def calculate_week_range(stat_date: pd.Timestamp) -> tuple[pd.Timestamp, pd.Timestamp]:
    normalized_date = pd.Timestamp(stat_date).normalize()
    days_since_saturday = (normalized_date.weekday() - 5) % 7
    week_start = normalized_date - pd.Timedelta(days=days_since_saturday)
    week_end = week_start + pd.Timedelta(days=6)
    return week_start, week_end


def _read_single_excel(source_name: str, payload: object) -> pd.DataFrame:
    frame = pd.read_excel(payload)
    frame["来源文件"] = source_name
    return frame


def load_input_files(paths: Sequence[str | Path] | None = None, files: Sequence[InMemoryFile] | None = None) -> pd.DataFrame:
    if not paths and not files:
        raise ValueError("请至少选择一个 Excel 或 ZIP 文件。")

    frames: list[pd.DataFrame] = []

    if paths:
        for raw_path in paths:
            path = Path(raw_path)
            suffix = path.suffix.lower()
            if suffix in {".xlsx", ".xls", ".xlsm"}:
                frames.append(_read_single_excel(path.name, path))
                continue

            if suffix == ".zip":
                with zipfile.ZipFile(path, "r") as archive:
                    members = [
                        name
                        for name in archive.namelist()
                        if name.lower().endswith((".xlsx", ".xls", ".xlsm"))
                    ]
                    if not members:
                        raise ValueError(f"{path.name} 中没有可读取的 Excel 文件。")
                    for member in members:
                        with archive.open(member, "r") as file_handle:
                            content = BytesIO(file_handle.read())
                        frames.append(_read_single_excel(f"{path.name}:{member}", content))
                continue

            raise ValueError(f"暂不支持的文件类型: {path.name}")

    if files:
        for file in files:
            suffix = Path(file.name).suffix.lower()
            if suffix in {".xlsx", ".xls", ".xlsm"}:
                frames.append(_read_single_excel(file.name, BytesIO(file.content)))
                continue

            if suffix == ".zip":
                with zipfile.ZipFile(BytesIO(file.content), "r") as archive:
                    members = [
                        name
                        for name in archive.namelist()
                        if name.lower().endswith((".xlsx", ".xls", ".xlsm"))
                    ]
                    if not members:
                        raise ValueError(f"{file.name} 中没有可读取的 Excel 文件。")
                    for member in members:
                        with archive.open(member, "r") as file_handle:
                            content = BytesIO(file_handle.read())
                        frames.append(_read_single_excel(f"{file.name}:{member}", content))
                continue

            raise ValueError(f"暂不支持的文件类型: {file.name}")

    combined = pd.concat(frames, ignore_index=True)
    return combined


def clean_events(raw_events: pd.DataFrame) -> pd.DataFrame:
    missing_columns = [column for column in REQUIRED_COLUMNS if column not in raw_events.columns]
    if missing_columns:
        raise ValueError(f"缺少必要列: {', '.join(missing_columns)}")

    events = raw_events.copy()
    for column in ("人员姓名", "门禁点", "门禁点区域", "出/入", "来源文件"):
        if column in events.columns:
            events[column] = events[column].map(normalize_text)
    events["工号"] = events["工号"].map(normalize_workno)
    events["事件时间"] = pd.to_datetime(
        events["事件时间"].map(normalize_text),
        errors="coerce",
    )
    events["出入方向"] = [
        normalize_direction(direction, door_name)
        for direction, door_name in zip(events["出/入"], events["门禁点"])
    ]

    events = events.dropna(subset=["事件时间"])
    events = events[
        (events["人员姓名"] != "")
        & (events["工号"] != "")
        & (events["门禁点区域"] != "")
        & (events["出入方向"].isin(["入", "出"]))
    ]
    events = events.sort_values(["人员姓名", "工号", "事件时间", "门禁点"]).reset_index(drop=True)
    return events


def detect_primary_workshop_areas(events: pd.DataFrame) -> pd.DataFrame:
    candidate_mask = events["门禁点区域"].map(is_candidate_workshop_area)
    area_counts = (
        events.loc[candidate_mask]
        .groupby(["人员姓名", "工号", "门禁点区域"], as_index=False)
        .size()
        .rename(columns={"size": "有效记录数", "门禁点区域": "主车间区域"})
    )
    if area_counts.empty:
        raise ValueError("没有识别到有效的更衣室门禁区域，无法统计车间时长。")

    area_counts = area_counts.sort_values(
        ["人员姓名", "工号", "有效记录数", "主车间区域"],
        ascending=[True, True, False, True],
    )
    primary_areas = (
        area_counts.groupby(["人员姓名", "工号"], as_index=False)
        .first()
        .reset_index(drop=True)
    )
    return primary_areas


def _build_workshop_events(events: pd.DataFrame, primary_areas: pd.DataFrame) -> pd.DataFrame:
    tagged_events = events.merge(primary_areas, on=["人员姓名", "工号"], how="left")
    workshop_events = tagged_events[
        tagged_events["门禁点区域"] == tagged_events["主车间区域"]
    ].copy()
    return workshop_events


def _deduplicate_events(group: pd.DataFrame, duplicate_seconds: int) -> pd.DataFrame:
    kept_rows: list[dict[str, object]] = []
    previous_direction = ""
    previous_time: pd.Timestamp | None = None

    for row in group.to_dict("records"):
        current_time = row["事件时间"]
        current_direction = row["出入方向"]
        if (
            previous_time is not None
            and current_direction == previous_direction
            and (current_time - previous_time).total_seconds() <= duplicate_seconds
        ):
            continue

        kept_rows.append(row)
        previous_direction = current_direction
        previous_time = current_time

    return pd.DataFrame(kept_rows)


def build_sessions(events: pd.DataFrame, primary_areas: pd.DataFrame, duplicate_seconds: int) -> pd.DataFrame:
    workshop_events = _build_workshop_events(events, primary_areas)
    if workshop_events.empty:
        return pd.DataFrame(
            columns=[
                "人员姓名",
                "工号",
                "主车间区域",
                "进车间时间",
                "出车间时间",
                "单次在车间秒数",
                "进门禁点",
                "出门禁点",
                "进记录来源",
                "出记录来源",
            ]
        )

    workshop_events = workshop_events.sort_values(["人员姓名", "工号", "事件时间", "门禁点"])
    session_rows: list[dict[str, object]] = []

    for (name, workno), group in workshop_events.groupby(["人员姓名", "工号"], sort=False):
        deduplicated = _deduplicate_events(group, duplicate_seconds)
        open_entry: dict[str, object] | None = None

        for row in deduplicated.to_dict("records"):
            direction = row["出入方向"]
            event_time = row["事件时间"]
            if direction == "入":
                open_entry = row
                continue

            if open_entry is None or event_time <= open_entry["事件时间"]:
                continue

            duration_seconds = int((event_time - open_entry["事件时间"]).total_seconds())
            session_rows.append(
                {
                    "人员姓名": name,
                    "工号": workno,
                    "主车间区域": row["主车间区域"],
                    "进车间时间": open_entry["事件时间"],
                    "出车间时间": event_time,
                    "单次在车间秒数": duration_seconds,
                    "进门禁点": open_entry["门禁点"],
                    "出门禁点": row["门禁点"],
                    "进记录来源": open_entry.get("来源文件", ""),
                    "出记录来源": row.get("来源文件", ""),
                }
            )
            open_entry = None

    sessions = pd.DataFrame(session_rows)
    if sessions.empty:
        return sessions

    sessions = sessions.sort_values(["人员姓名", "工号", "进车间时间", "出车间时间"]).reset_index(drop=True)
    return sessions


def _classify_person_shift_from_sessions(group: pd.DataFrame) -> str:
    total_sessions = len(group)
    if total_sessions == 0:
        return DAY_SHIFT_NAME

    start_times = group["进车间时间"]
    end_times = group["出车间时间"]
    cross_midnight_count = (end_times.dt.normalize() > start_times.dt.normalize()).sum()
    late_start_count = (start_times.dt.hour >= NIGHT_SHIFT_LATE_START_HOUR).sum()
    early_start_count = (start_times.dt.hour < NIGHT_SHIFT_EARLY_START_HOUR).sum()
    early_end_count = (end_times.dt.hour < NIGHT_SHIFT_END_HOUR).sum()

    strong_night_markers = int(cross_midnight_count + early_start_count + early_end_count)
    strong_threshold = max(2, math.ceil(total_sessions * 0.2))
    late_start_threshold = max(3, math.ceil(total_sessions * 0.5))
    is_night_shift = (
        strong_night_markers >= strong_threshold
        or late_start_count >= late_start_threshold
    )
    return NIGHT_SHIFT_NAME if is_night_shift else DAY_SHIFT_NAME


def _build_shift_blocks(sessions: pd.DataFrame) -> pd.DataFrame:
    if sessions.empty:
        return sessions.copy()

    block_groups: list[pd.DataFrame] = []
    break_seconds = SHIFT_BLOCK_BREAK_HOURS * 3600
    sort_columns = ["人员姓名", "工号", "进车间时间", "出车间时间"]

    for _, group in sessions.sort_values(sort_columns).groupby(["人员姓名", "工号"], sort=False):
        current = group.copy()
        previous_end = current["出车间时间"].shift()
        gap_seconds = (current["进车间时间"] - previous_end).dt.total_seconds()
        starts_new_block = previous_end.isna() | gap_seconds.gt(break_seconds)
        current["班次块序号"] = starts_new_block.cumsum()
        block_groups.append(current)

    return pd.concat(block_groups, ignore_index=True)


def _classify_shift_block(group: pd.DataFrame, default_shift: str) -> str:
    if group.empty:
        return default_shift

    start_times = group["进车间时间"]
    end_times = group["出车间时间"]
    block_start = start_times.min()
    block_end = end_times.max()
    block_duration_seconds = int((block_end - block_start).total_seconds())
    crosses_midnight = (end_times.dt.normalize() > start_times.dt.normalize()).any()
    block_start_hour = block_start.hour
    block_end_hour = block_end.hour

    if crosses_midnight:
        return NIGHT_SHIFT_NAME

    if block_start_hour < NIGHT_SHIFT_EARLY_START_HOUR:
        return NIGHT_SHIFT_NAME if block_end_hour <= 11 or block_duration_seconds <= 6 * 3600 else DAY_SHIFT_NAME
    if block_start_hour < NIGHT_SHIFT_END_HOUR:
        return NIGHT_SHIFT_NAME if block_end_hour <= 10 and block_duration_seconds <= 6 * 3600 else DAY_SHIFT_NAME
    if block_start_hour >= 19:
        if block_end_hour >= 21 or block_duration_seconds >= 2 * 3600:
            return NIGHT_SHIFT_NAME
        return default_shift
    if block_start_hour >= NIGHT_SHIFT_END_HOUR and block_start_hour < 19:
        return DAY_SHIFT_NAME
    return default_shift


def assign_shifts_to_sessions(sessions: pd.DataFrame) -> pd.DataFrame:
    if sessions.empty:
        columns = list(sessions.columns)
        if "班次" not in columns:
            columns.insert(2, "班次")
        return pd.DataFrame(columns=columns)

    sessions_with_blocks = _build_shift_blocks(sessions)
    dominant_shift_by_person = {
        (name, workno): _classify_person_shift_from_sessions(group)
        for (name, workno), group in sessions_with_blocks.groupby(["人员姓名", "工号"], sort=False)
    }

    shift_rows: list[dict[str, object]] = []
    for (name, workno, block_id), group in sessions_with_blocks.groupby(["人员姓名", "工号", "班次块序号"], sort=False):
        default_shift = dominant_shift_by_person[(name, workno)]
        shift_rows.append(
            {
                "人员姓名": name,
                "工号": workno,
                "班次块序号": block_id,
                "班次": _classify_shift_block(group, default_shift),
            }
        )

    block_shifts = pd.DataFrame(shift_rows)
    merged = sessions_with_blocks.merge(block_shifts, on=["人员姓名", "工号", "班次块序号"], how="left")
    merged["班次"] = merged["班次"].fillna(DAY_SHIFT_NAME)
    return merged[
        [
            "人员姓名",
            "工号",
            "班次",
            "主车间区域",
            "进车间时间",
            "出车间时间",
            "单次在车间秒数",
            "进门禁点",
            "出门禁点",
            "进记录来源",
            "出记录来源",
        ]
    ]


def add_shift_to_primary_areas(primary_areas: pd.DataFrame, sessions: pd.DataFrame) -> pd.DataFrame:
    if primary_areas.empty:
        return primary_areas

    if sessions.empty:
        merged = primary_areas.copy()
        merged["班次"] = DAY_SHIFT_NAME
        return merged[["人员姓名", "工号", "班次", "有效记录数", "主车间区域"]]

    shifts = sessions[["人员姓名", "工号", "班次"]].drop_duplicates().copy()
    merged = primary_areas.merge(shifts, on=["人员姓名", "工号"], how="left")
    merged["班次"] = merged["班次"].fillna(DAY_SHIFT_NAME)
    return merged[["人员姓名", "工号", "班次", "有效记录数", "主车间区域"]].sort_values(
        ["班次", "人员姓名", "工号", "主车间区域"]
    ).reset_index(drop=True)


def resolve_session_stat_date(session: pd.Series) -> pd.Timestamp:
    stat_date = pd.Timestamp(session["进车间时间"]).normalize()
    if session.get("班次") == NIGHT_SHIFT_NAME and pd.Timestamp(session["进车间时间"]).hour < NIGHT_SHIFT_END_HOUR:
        return stat_date - pd.Timedelta(days=1)
    return stat_date


def filter_sessions(
    sessions: pd.DataFrame,
    name_keyword: str = "",
    workno_keyword: str = "",
    shift_keyword: str = "",
    start_time: pd.Timestamp | None = None,
    end_time: pd.Timestamp | None = None,
) -> pd.DataFrame:
    filtered = sessions.copy()
    if filtered.empty:
        return filtered

    name_keywords = split_filter_values(name_keyword)
    workno_keywords = split_filter_values(workno_keyword)
    shift_keywords = split_filter_values(shift_keyword)

    if name_keywords:
        filtered = filtered[filtered["人员姓名"].isin(name_keywords)]
    if workno_keywords:
        filtered = filtered[filtered["工号"].isin(workno_keywords)]
    if shift_keywords:
        filtered = filtered[filtered["班次"].isin(shift_keywords)]
    if start_time is not None:
        filtered = filtered[filtered["出车间时间"] >= start_time]
    if end_time is not None:
        filtered = filtered[filtered["进车间时间"] <= end_time]

    return filtered.sort_values(["班次", "人员姓名", "工号", "进车间时间"]).reset_index(drop=True)


def filter_primary_areas(
    primary_areas: pd.DataFrame,
    name_keyword: str = "",
    workno_keyword: str = "",
    shift_keyword: str = "",
) -> pd.DataFrame:
    filtered = primary_areas.copy()
    if filtered.empty:
        return filtered

    name_keywords = split_filter_values(name_keyword)
    workno_keywords = split_filter_values(workno_keyword)
    shift_keywords = split_filter_values(shift_keyword)

    if name_keywords:
        filtered = filtered[filtered["人员姓名"].isin(name_keywords)]
    if workno_keywords:
        filtered = filtered[filtered["工号"].isin(workno_keywords)]
    if shift_keywords:
        filtered = filtered[filtered["班次"].isin(shift_keywords)]

    return filtered.sort_values(["班次", "人员姓名", "工号", "主车间区域"]).reset_index(drop=True)


def build_output_tables(sessions: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    if sessions.empty:
        empty_detail = pd.DataFrame(
            columns=[
                "人员姓名",
                "工号",
                "班次",
                "主车间区域",
                "统计日期",
                "周开始日期",
                "周结束日期",
                "统计月份",
                "进车间时间",
                "出车间时间",
                "单次在车间时长",
                "当天在车间时长",
                "当周在车间时长",
                "当月在车间时长",
                "进门禁点",
                "出门禁点",
                "进记录来源",
                "出记录来源",
            ]
        )
        empty_daily = pd.DataFrame(
            columns=[
                "人员姓名",
                "工号",
                "班次",
                "主车间区域",
                "统计日期",
                "单日进出次数",
                "首次进车间时间",
                "最后出车间时间",
                "当天在车间时长",
                "当周在车间时长",
                "当月在车间时长",
                "当天最长车间外出时长",
                "当天最长车间外出开始时间",
                "当天最长车间外出结束时间",
            ]
        )
        empty_weekly = pd.DataFrame(
            columns=["人员姓名", "工号", "班次", "主车间区域", "周开始日期", "周结束日期", "当周在车间时长"]
        )
        empty_monthly = pd.DataFrame(
            columns=["人员姓名", "工号", "班次", "主车间区域", "统计月份", "当月在车间时长"]
        )
        return empty_detail, empty_daily, empty_weekly, empty_monthly

    detail = sessions.copy()
    detail["统计日期"] = detail.apply(resolve_session_stat_date, axis=1)
    week_ranges = detail["统计日期"].map(calculate_week_range)
    detail["周开始日期"] = week_ranges.map(lambda item: item[0])
    detail["周结束日期"] = week_ranges.map(lambda item: item[1])
    detail["统计月份"] = detail["统计日期"].dt.strftime("%Y-%m")

    key_columns = ["人员姓名", "工号", "班次", "主车间区域"]

    daily_totals = (
        detail.groupby(key_columns + ["统计日期"], as_index=False)["单次在车间秒数"]
        .sum()
        .rename(columns={"单次在车间秒数": "当天在车间秒数"})
    )
    weekly_totals = (
        detail.groupby(key_columns + ["周开始日期", "周结束日期"], as_index=False)["单次在车间秒数"]
        .sum()
        .rename(columns={"单次在车间秒数": "当周在车间秒数"})
    )
    monthly_totals = (
        detail.groupby(key_columns + ["统计月份"], as_index=False)["单次在车间秒数"]
        .sum()
        .rename(columns={"单次在车间秒数": "当月在车间秒数"})
    )

    detail = detail.merge(daily_totals, on=key_columns + ["统计日期"], how="left")
    detail = detail.merge(weekly_totals, on=key_columns + ["周开始日期", "周结束日期"], how="left")
    detail = detail.merge(monthly_totals, on=key_columns + ["统计月份"], how="left")

    detail["单次在车间时长"] = detail["单次在车间秒数"].map(format_duration)
    detail["当天在车间时长"] = detail["当天在车间秒数"].map(format_duration)
    detail["当周在车间时长"] = detail["当周在车间秒数"].map(format_duration)
    detail["当月在车间时长"] = detail["当月在车间秒数"].map(format_duration)

    detail_sheet = detail[
        [
            "人员姓名",
            "工号",
            "班次",
            "主车间区域",
            "统计日期",
            "周开始日期",
            "周结束日期",
            "统计月份",
            "进车间时间",
            "出车间时间",
            "单次在车间时长",
            "当天在车间时长",
            "当周在车间时长",
            "当月在车间时长",
            "进门禁点",
            "出门禁点",
            "进记录来源",
            "出记录来源",
        ]
    ].copy()

    daily_base = (
        detail.groupby(key_columns + ["统计日期", "周开始日期", "周结束日期", "统计月份"], as_index=False)
        .agg(
            单日进出次数=("单次在车间秒数", "size"),
            首次进车间时间=("进车间时间", "min"),
            最后出车间时间=("出车间时间", "max"),
            当天在车间秒数=("单次在车间秒数", "sum"),
        )
    )
    daily_sheet = daily_base.merge(
        weekly_totals,
        on=key_columns + ["周开始日期", "周结束日期"],
        how="left",
    ).merge(
        monthly_totals,
        on=key_columns + ["统计月份"],
        how="left",
    )

    daily_sheet["当天在车间时长"] = daily_sheet["当天在车间秒数"].map(format_duration)
    daily_sheet["当周在车间时长"] = daily_sheet["当周在车间秒数"].map(format_duration)
    daily_sheet["当月在车间时长"] = daily_sheet["当月在车间秒数"].map(format_duration)
    outside_daily = build_daily_outside_summary(detail)
    daily_sheet = daily_sheet.merge(
        outside_daily,
        on=["人员姓名", "工号", "班次", "主车间区域", "统计日期"],
        how="left",
    )

    base_daily_columns = [
        "人员姓名",
        "工号",
        "班次",
        "主车间区域",
        "统计日期",
        "单日进出次数",
        "首次进车间时间",
        "最后出车间时间",
        "当天在车间时长",
        "当周在车间时长",
        "当月在车间时长",
        "当天最长车间外出时长",
        "当天最长车间外出开始时间",
        "当天最长车间外出结束时间",
    ]
    outside_columns = [
        column
        for column in daily_sheet.columns
        if column.startswith("车间外时间") or column.startswith("车间外开始时间") or column.startswith("车间外结束时间")
    ]
    daily_sheet = daily_sheet[base_daily_columns + outside_columns].sort_values(["班次", "人员姓名", "工号", "统计日期"])

    weekly_sheet = weekly_totals.copy()
    weekly_sheet["当周在车间时长"] = weekly_sheet["当周在车间秒数"].map(format_duration)
    weekly_sheet = weekly_sheet[
        ["人员姓名", "工号", "班次", "主车间区域", "周开始日期", "周结束日期", "当周在车间时长"]
    ].sort_values(["班次", "人员姓名", "工号", "周开始日期"])

    monthly_sheet = monthly_totals.copy()
    monthly_sheet["当月在车间时长"] = monthly_sheet["当月在车间秒数"].map(format_duration)
    monthly_sheet = monthly_sheet[
        ["人员姓名", "工号", "班次", "主车间区域", "统计月份", "当月在车间时长"]
    ].sort_values(["班次", "人员姓名", "工号", "统计月份"])

    return detail_sheet, daily_sheet, weekly_sheet, monthly_sheet


def build_daily_outside_summary(detail: pd.DataFrame) -> pd.DataFrame:
    if detail.empty:
        return pd.DataFrame(
            columns=[
                "人员姓名",
                "工号",
                "班次",
                "主车间区域",
                "统计日期",
                "当天最长车间外出时长",
                "当天最长车间外出开始时间",
                "当天最长车间外出结束时间",
            ]
        )

    rows: list[dict[str, object]] = []
    max_outside_count = 0
    grouped_outside: list[dict[str, object]] = []

    for (name, workno, shift_name, area), group in detail.sort_values(["进车间时间"]).groupby(
        ["人员姓名", "工号", "班次", "主车间区域"], sort=False
    ):
        records = group.to_dict("records")
        daily_map: dict[pd.Timestamp, list[dict[str, object]]] = {}

        for current, nxt in zip(records, records[1:]):
            outside_start = current["出车间时间"]
            outside_end = nxt["进车间时间"]
            if outside_end <= outside_start:
                continue
            if current["统计日期"] != nxt["统计日期"]:
                continue

            stat_date = current["统计日期"]
            daily_map.setdefault(stat_date, []).append(
                {
                    "start": outside_start,
                    "end": outside_end,
                    "seconds": int((outside_end - outside_start).total_seconds()),
                }
            )

        for stat_date, items in daily_map.items():
            max_outside_count = max(max_outside_count, len(items))
            grouped_outside.append(
                {
                    "人员姓名": name,
                    "工号": workno,
                    "班次": shift_name,
                    "主车间区域": area,
                    "统计日期": stat_date,
                    "items": items,
                }
            )

    for record in grouped_outside:
        items = record["items"]
        longest = max(items, key=lambda item: item["seconds"]) if items else None
        row = {
            "人员姓名": record["人员姓名"],
            "工号": record["工号"],
            "班次": record["班次"],
            "主车间区域": record["主车间区域"],
            "统计日期": record["统计日期"],
            "当天最长车间外出时长": format_duration(longest["seconds"]) if longest else "",
            "当天最长车间外出开始时间": longest["start"] if longest else pd.NaT,
            "当天最长车间外出结束时间": longest["end"] if longest else pd.NaT,
        }
        for index in range(1, max_outside_count + 1):
            duration_key = f"车间外时间{index}"
            start_key = f"车间外开始时间{index}"
            end_key = f"车间外结束时间{index}"
            if index <= len(items):
                row[duration_key] = format_duration(items[index - 1]["seconds"])
                row[start_key] = items[index - 1]["start"]
                row[end_key] = items[index - 1]["end"]
            else:
                row[duration_key] = ""
                row[start_key] = pd.NaT
                row[end_key] = pd.NaT
        rows.append(row)

    if not rows:
        return pd.DataFrame(
            columns=[
                "人员姓名",
                "工号",
                "班次",
                "主车间区域",
                "统计日期",
                "当天最长车间外出时长",
                "当天最长车间外出开始时间",
                "当天最长车间外出结束时间",
            ]
        )

    return pd.DataFrame(rows)


def generate_stats(
    paths: Sequence[str | Path] | None = None,
    files: Sequence[InMemoryFile] | None = None,
    name_keyword: str = "",
    workno_keyword: str = "",
    shift_keyword: str = "",
    start_text: str = "",
    end_text: str = "",
    duplicate_seconds: int = DEFAULT_DUPLICATE_SECONDS,
) -> StatsResult:
    raw_events = load_input_files(paths=paths, files=files)
    cleaned_events = clean_events(raw_events)
    primary_areas = detect_primary_workshop_areas(cleaned_events)
    sessions = build_sessions(cleaned_events, primary_areas, duplicate_seconds)
    sessions = assign_shifts_to_sessions(sessions)
    primary_areas = add_shift_to_primary_areas(primary_areas, sessions)

    start_time = parse_filter_datetime(start_text, is_end=False) if start_text else None
    end_time = parse_filter_datetime(end_text, is_end=True) if end_text else None
    filtered_sessions = filter_sessions(
        sessions,
        name_keyword=name_keyword,
        workno_keyword=workno_keyword,
        shift_keyword=shift_keyword,
        start_time=start_time,
        end_time=end_time,
    )
    filtered_primary_areas = filter_primary_areas(
        primary_areas,
        name_keyword=name_keyword,
        workno_keyword=workno_keyword,
        shift_keyword=shift_keyword,
    )

    detail_sheet, daily_sheet, weekly_sheet, monthly_sheet = build_output_tables(filtered_sessions)
    filter_parts = []
    name_keywords = split_filter_values(name_keyword)
    workno_keywords = split_filter_values(workno_keyword)
    shift_keywords = split_filter_values(shift_keyword)
    if name_keywords:
        filter_parts.append(f"姓名={','.join(name_keywords)}")
    if workno_keywords:
        filter_parts.append(f"工号={','.join(workno_keywords)}")
    if shift_keywords:
        filter_parts.append(f"班次={','.join(shift_keywords)}")
    if start_text:
        filter_parts.append(f"开始时间>={start_text}")
    if end_text:
        filter_parts.append(f"结束时间<={end_text}")
    filter_summary = "筛选条件: " + ("；".join(filter_parts) if filter_parts else "未筛选")
    return StatsResult(
        raw_events=cleaned_events,
        primary_areas=filtered_primary_areas,
        sessions=filtered_sessions,
        detail_sheet=detail_sheet,
        daily_sheet=daily_sheet,
        weekly_sheet=weekly_sheet,
        monthly_sheet=monthly_sheet,
        filter_summary=filter_summary,
    )


def build_data_profile(paths: Sequence[str | Path] | None = None, files: Sequence[InMemoryFile] | None = None) -> DataProfile:
    raw_events = load_input_files(paths=paths, files=files)
    cleaned_events = clean_events(raw_events)
    primary_areas = detect_primary_workshop_areas(cleaned_events)
    sessions = build_sessions(cleaned_events, primary_areas, DEFAULT_DUPLICATE_SECONDS)
    sessions = assign_shifts_to_sessions(sessions)
    primary_areas = add_shift_to_primary_areas(primary_areas, sessions)
    names = sorted(value for value in primary_areas["人员姓名"].dropna().unique() if value)
    worknos = sorted(value for value in primary_areas["工号"].dropna().unique() if value)
    shift_values = sorted(value for value in primary_areas["班次"].dropna().unique() if value)
    min_time = cleaned_events["事件时间"].min() if not cleaned_events.empty else None
    max_time = cleaned_events["事件时间"].max() if not cleaned_events.empty else None
    return DataProfile(
        names=names,
        worknos=worknos,
        shifts=shift_values,
        min_time=min_time,
        max_time=max_time,
    )


def autofit_worksheet(worksheet) -> None:
    for column_cells in worksheet.columns:
        values = ["" if cell.value is None else str(cell.value) for cell in column_cells]
        max_length = min(max((len(value) for value in values), default=0) + 2, 60)
        column_letter = column_cells[0].column_letter
        worksheet.column_dimensions[column_letter].width = max_length


def enable_autofilter(worksheet) -> None:
    if worksheet.max_row >= 1 and worksheet.max_column >= 1:
        worksheet.auto_filter.ref = worksheet.dimensions


def style_worksheet(worksheet) -> None:
    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True)
    zebra_fill = PatternFill("solid", fgColor="F7FBFF")
    border = Border(
        left=Side(style="thin", color="D9E2EC"),
        right=Side(style="thin", color="D9E2EC"),
        top=Side(style="thin", color="D9E2EC"),
        bottom=Side(style="thin", color="D9E2EC"),
    )
    center_alignment = Alignment(horizontal="center", vertical="center")
    left_alignment = Alignment(horizontal="left", vertical="center")

    datetime_columns = {"首次进车间时间", "最后出车间时间", "进车间时间", "出车间时间", "事件时间"}
    date_columns = {"统计日期", "周开始日期", "周结束日期"}

    for row in worksheet.iter_rows():
        for cell in row:
            cell.border = border
            if cell.row == 1:
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = center_alignment
            else:
                if cell.row % 2 == 0:
                    cell.fill = zebra_fill

                header = worksheet.cell(row=1, column=cell.column).value
                if header in datetime_columns and cell.value:
                    cell.number_format = "yyyy-mm-dd hh:mm:ss"
                    cell.alignment = center_alignment
                elif header in date_columns and cell.value:
                    cell.number_format = "yyyy-mm-dd"
                    cell.alignment = center_alignment
                elif header and ("时长" in str(header) or "次数" in str(header) or "工号" in str(header) or header == "班次"):
                    cell.alignment = center_alignment
                else:
                    cell.alignment = left_alignment


def style_export_sheet(worksheet) -> None:
    title_fill = PatternFill("solid", fgColor="0B3954")
    subtitle_fill = PatternFill("solid", fgColor="EAF4FC")
    header_fill = PatternFill("solid", fgColor="1F4E78")
    highlight_fill = PatternFill("solid", fgColor="FFF4CC")
    zebra_fill = PatternFill("solid", fgColor="F8FBFE")
    outside_group_fills = [
        PatternFill("solid", fgColor="EAF4FC"),
        PatternFill("solid", fgColor="E9F7EF"),
        PatternFill("solid", fgColor="FDF2E9"),
        PatternFill("solid", fgColor="F4ECF7"),
        PatternFill("solid", fgColor="FDEDEC"),
        PatternFill("solid", fgColor="EBF5FB"),
    ]
    title_font = Font(color="FFFFFF", bold=True, size=14)
    subtitle_font = Font(color="243B53", italic=True)
    header_font = Font(color="FFFFFF", bold=True)
    border = Border(
        left=Side(style="thin", color="D9E2EC"),
        right=Side(style="thin", color="D9E2EC"),
        top=Side(style="thin", color="D9E2EC"),
        bottom=Side(style="thin", color="D9E2EC"),
    )
    center = Alignment(horizontal="center", vertical="center")
    left = Alignment(horizontal="left", vertical="center", wrap_text=True)

    max_col = worksheet.max_column
    worksheet.merge_cells(start_row=1, start_column=1, end_row=1, end_column=max_col)
    worksheet.merge_cells(start_row=2, start_column=1, end_row=2, end_column=max_col)
    worksheet.freeze_panes = "A4"
    worksheet.auto_filter.ref = f"A3:{worksheet.cell(row=worksheet.max_row, column=max_col).coordinate}"
    worksheet.row_dimensions[1].height = 24
    worksheet.row_dimensions[2].height = 22
    worksheet.row_dimensions[3].height = 22

    outside_header_fills: dict[str, PatternFill] = {}
    for column_index in range(1, max_col + 1):
        header = worksheet.cell(row=3, column=column_index).value
        if not header:
            continue
        header_text = str(header)
        if header_text.startswith("车间外时间") or header_text.startswith("车间外开始时间") or header_text.startswith("车间外结束时间"):
            suffix = header_text.split("间")[-1]
            suffix = "".join(ch for ch in suffix if ch.isdigit())
            if suffix:
                fill = outside_group_fills[(int(suffix) - 1) % len(outside_group_fills)]
                outside_header_fills[header_text] = fill

    for row in worksheet.iter_rows():
        for cell in row:
            cell.border = border
            if cell.row == 1:
                cell.fill = title_fill
                cell.font = title_font
                cell.alignment = center
            elif cell.row == 2:
                cell.fill = subtitle_fill
                cell.font = subtitle_font
                cell.alignment = left
            elif cell.row == 3:
                header = worksheet.cell(row=3, column=cell.column).value
                if header in outside_header_fills:
                    cell.fill = outside_header_fills[header]
                    cell.font = Font(color="243B53", bold=True)
                elif header in {"当天最长车间外出时长", "当天最长车间外出开始时间", "当天最长车间外出结束时间"}:
                    cell.fill = highlight_fill
                    cell.font = Font(color="7A3E00", bold=True)
                else:
                    cell.fill = header_fill
                    cell.font = header_font
                cell.alignment = center
            else:
                if cell.row % 2 == 0:
                    cell.fill = zebra_fill
                header = worksheet.cell(row=3, column=cell.column).value
                if header in outside_header_fills:
                    cell.fill = outside_header_fills[header]
                    cell.alignment = center if "时间" in str(header) else left
                elif header in {"当天在车间时长", "当周在车间时长", "当月在车间时长", "当天最长车间外出时长"}:
                    cell.fill = highlight_fill
                    cell.alignment = center
                elif header in {"统计日期"} and cell.value:
                    cell.number_format = "yyyy-mm-dd"
                    cell.alignment = center
                elif (
                    header in {"首次进车间时间", "最后出车间时间", "当天最长车间外出开始时间", "当天最长车间外出结束时间"}
                    or str(header).startswith("车间外开始时间")
                    or str(header).startswith("车间外结束时间")
                ) and cell.value:
                    cell.number_format = "yyyy-mm-dd hh:mm:ss"
                    cell.alignment = center
                elif header in {"工号", "班次"}:
                    cell.alignment = center
                else:
                    cell.alignment = left


def apply_export_column_widths(worksheet) -> None:
    width_overrides = {
        "人员姓名": 12,
        "工号": 12,
        "班次": 10,
        "主车间区域": 32,
        "统计日期": 12,
        "首次进车间时间": 20,
        "最后出车间时间": 20,
        "当天在车间时长": 14,
        "当周在车间时长": 14,
        "当月在车间时长": 14,
        "当天最长车间外出时长": 16,
        "当天最长车间外出开始时间": 20,
        "当天最长车间外出结束时间": 20,
    }
    for column_index in range(1, worksheet.max_column + 1):
        header = worksheet.cell(row=3, column=column_index).value
        if not header:
            continue
        header_text = str(header)
        if header_text.startswith("车间外时间"):
            width = 14
        elif header_text.startswith("车间外开始时间") or header_text.startswith("车间外结束时间"):
            width = 20
        else:
            width = width_overrides.get(header_text)
        if width:
            worksheet.column_dimensions[worksheet.cell(row=3, column=column_index).column_letter].width = width


def _write_main_export_sheet(worksheet, result: StatsResult) -> None:
    export_sheet = build_export_sheet(result)
    worksheet.append(["车间时长筛选统计结果"])
    worksheet.append([result.filter_summary or "筛选条件: 未筛选"])
    worksheet.append(list(export_sheet.columns))
    for row in export_sheet.itertuples(index=False, name=None):
        worksheet.append(list(row))

    autofit_worksheet(worksheet)
    style_export_sheet(worksheet)
    apply_export_column_widths(worksheet)


def _write_dataframe_sheet(worksheet, dataframe: pd.DataFrame) -> None:
    worksheet.append(list(dataframe.columns))
    for row in dataframe.itertuples(index=False, name=None):
        worksheet.append(list(row))

    worksheet.freeze_panes = "A2"
    enable_autofilter(worksheet)
    autofit_worksheet(worksheet)
    style_worksheet(worksheet)


def build_export_workbook(result: StatsResult) -> Workbook:
    workbook = Workbook()
    sheet_specs = [
        ("明细统计", result.detail_sheet),
        ("按日汇总", result.daily_sheet),
        ("按周汇总", result.weekly_sheet),
        ("按月汇总", result.monthly_sheet),
        ("人员主车间", result.primary_areas),
    ]
    for index, (title, dataframe) in enumerate(sheet_specs):
        current_sheet = workbook.active if index == 0 else workbook.create_sheet(title=title)
        current_sheet.title = title
        _write_dataframe_sheet(current_sheet, dataframe)

    return workbook


def export_result(result: StatsResult, output_path: str | Path) -> None:
    output = Path(output_path)
    workbook = build_export_workbook(result)
    workbook.save(output)


def build_export_sheet(result: StatsResult) -> pd.DataFrame:
    if result.daily_sheet.empty:
        return pd.DataFrame(
            columns=[
                "人员姓名",
                "工号",
                "班次",
                "主车间区域",
                "统计日期",
                "首次进车间时间",
                "最后出车间时间",
                "当天在车间时长",
                "当周在车间时长",
                "当月在车间时长",
                "当天最长车间外出时长",
                "当天最长车间外出开始时间",
                "当天最长车间外出结束时间",
            ]
        )

    outside_duration_columns = sorted(
        [column for column in result.daily_sheet.columns if column.startswith("车间外时间")],
        key=lambda value: int(value.replace("车间外时间", "")),
    )
    outside_columns: list[str] = []
    for duration_column in outside_duration_columns:
        suffix = duration_column.replace("车间外时间", "")
        outside_columns.extend(
            [
                duration_column,
                f"车间外开始时间{suffix}",
                f"车间外结束时间{suffix}",
            ]
        )
    ordered_columns = [
        "人员姓名",
        "工号",
        "班次",
        "主车间区域",
        "统计日期",
        "首次进车间时间",
        "最后出车间时间",
        "当天在车间时长",
        "当周在车间时长",
        "当月在车间时长",
        *outside_columns,
        "当天最长车间外出时长",
        "当天最长车间外出开始时间",
        "当天最长车间外出结束时间",
    ]
    export_sheet = result.daily_sheet[ordered_columns].copy()
    return export_sheet.sort_values(["班次", "人员姓名", "工号", "统计日期"]).reset_index(drop=True)


def export_current_filter_bytes(result: StatsResult) -> bytes:
    workbook = build_export_workbook(result)
    output = BytesIO()
    workbook.save(output)
    return output.getvalue()


def summarize_result(result: StatsResult) -> str:
    people_count = result.sessions[["人员姓名", "工号"]].drop_duplicates().shape[0] if not result.sessions.empty else 0
    session_count = len(result.sessions)
    total_seconds = int(result.sessions["单次在车间秒数"].sum()) if not result.sessions.empty else 0
    return (
        f"人员数: {people_count} | "
        f"进出记录数: {session_count} | "
        f"累计车间时长: {format_duration(total_seconds)}"
    )
