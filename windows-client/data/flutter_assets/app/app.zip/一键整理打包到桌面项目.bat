@echo off
setlocal
cd /d "%~dp0"
for %%I in ("%~dp0.") do set "PROJECT_ROOT=%%~fI"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_release.ps1" -Target all -ProjectRootPath "%PROJECT_ROOT%"
if errorlevel 1 (
  echo.
  echo Build or sync failed. Check the error output above.
  if /I not "%~1"=="--no-pause" pause
  exit /b 1
)
echo.
echo Done. Output folders:
echo Client: build\dist\windows-client
echo Admin: build\dist\windows-license-admin
if /I not "%~1"=="--no-pause" pause
