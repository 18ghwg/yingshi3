from __future__ import annotations

from datetime import date, datetime
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import pandas as pd
import license_utils

from license_admin import normalize_expire_date
from license_utils import (
    LicenseError,
    clear_saved_license,
    decode_license_key,
    generate_license_key,
    get_machine_code,
    get_legacy_license_file_path,
    get_license_file_path,
    get_time_state_file_path,
    load_saved_license,
    refresh_time_integrity_state,
    save_activated_license,
    validate_license_key,
    verify_system_time_integrity,
)
from workshop_stats import add_shift_to_primary_areas, assign_shifts_to_sessions, build_output_tables, calculate_week_range


class WorkshopWeekRangeTests(unittest.TestCase):
    def test_week_range_uses_saturday_to_friday(self) -> None:
        start, end = calculate_week_range(pd.Timestamp("2026-05-01"))
        self.assertEqual(start, pd.Timestamp("2026-04-25"))
        self.assertEqual(end, pd.Timestamp("2026-05-01"))

        start, end = calculate_week_range(pd.Timestamp("2026-05-02"))
        self.assertEqual(start, pd.Timestamp("2026-05-02"))
        self.assertEqual(end, pd.Timestamp("2026-05-08"))

    def test_weekly_sheet_groups_records_by_saturday_friday_window(self) -> None:
        sessions = pd.DataFrame(
            [
                {
                    "人员姓名": "张三",
                    "工号": "1001",
                    "班次": "白班",
                    "主车间区域": "一车间更衣室",
                    "进车间时间": pd.Timestamp("2026-04-30 08:00:00"),
                    "出车间时间": pd.Timestamp("2026-04-30 10:00:00"),
                    "单次在车间秒数": 7200,
                    "进门禁点": "A进",
                    "出门禁点": "A出",
                    "进记录来源": "f1",
                    "出记录来源": "f1",
                },
                {
                    "人员姓名": "张三",
                    "工号": "1001",
                    "班次": "白班",
                    "主车间区域": "一车间更衣室",
                    "进车间时间": pd.Timestamp("2026-05-01 08:00:00"),
                    "出车间时间": pd.Timestamp("2026-05-01 11:00:00"),
                    "单次在车间秒数": 10800,
                    "进门禁点": "A进",
                    "出门禁点": "A出",
                    "进记录来源": "f2",
                    "出记录来源": "f2",
                },
                {
                    "人员姓名": "张三",
                    "工号": "1001",
                    "班次": "白班",
                    "主车间区域": "一车间更衣室",
                    "进车间时间": pd.Timestamp("2026-05-02 08:00:00"),
                    "出车间时间": pd.Timestamp("2026-05-02 09:00:00"),
                    "单次在车间秒数": 3600,
                    "进门禁点": "A进",
                    "出门禁点": "A出",
                    "进记录来源": "f3",
                    "出记录来源": "f3",
                },
            ]
        )

        _, _, weekly_sheet, _ = build_output_tables(sessions)

        self.assertEqual(len(weekly_sheet), 2)
        first_row = weekly_sheet.iloc[0].to_dict()
        second_row = weekly_sheet.iloc[1].to_dict()

        self.assertEqual(first_row["周开始日期"], pd.Timestamp("2026-04-25"))
        self.assertEqual(first_row["周结束日期"], pd.Timestamp("2026-05-01"))
        self.assertEqual(first_row["当周在车间时长"], "05:00:00")

        self.assertEqual(second_row["周开始日期"], pd.Timestamp("2026-05-02"))
        self.assertEqual(second_row["周结束日期"], pd.Timestamp("2026-05-08"))
        self.assertEqual(second_row["当周在车间时长"], "01:00:00")

    def test_detail_sheet_contains_expected_columns(self) -> None:
        sessions = pd.DataFrame(
            [
                {
                    "人员姓名": "张三",
                    "工号": "1001",
                    "班次": "白班",
                    "主车间区域": "一车间更衣室",
                    "进车间时间": pd.Timestamp("2026-05-01 08:00:00"),
                    "出车间时间": pd.Timestamp("2026-05-01 11:00:00"),
                    "单次在车间秒数": 10800,
                    "进门禁点": "A进",
                    "出门禁点": "A出",
                    "进记录来源": "f2",
                    "出记录来源": "f2",
                }
            ]
        )

        detail_sheet, _, _, _ = build_output_tables(sessions)
        self.assertEqual(
            list(detail_sheet.columns),
            [
                "人员姓名",
                "工号",
                "班次",
                "主车间区域",
                "统计日期",
                "周开始日期",
                "周结束日期",
                "统计月份",
                "进车间时间",
                "出车间时间",
                "单次在车间时长",
                "当天在车间时长",
                "当周在车间时长",
                "当月在车间时长",
                "进门禁点",
                "出门禁点",
                "进记录来源",
                "出记录来源",
            ],
        )

    def test_mixed_shift_person_is_split_into_day_and_night_records(self) -> None:
        raw_sessions = pd.DataFrame(
            [
                {
                    "人员姓名": "张三",
                    "工号": "1001",
                    "主车间区域": "一车间更衣室",
                    "进车间时间": pd.Timestamp("2026-05-01 07:50:00"),
                    "出车间时间": pd.Timestamp("2026-05-01 11:30:00"),
                    "单次在车间秒数": 13200,
                    "进门禁点": "A进",
                    "出门禁点": "A出",
                    "进记录来源": "day1",
                    "出记录来源": "day1",
                },
                {
                    "人员姓名": "张三",
                    "工号": "1001",
                    "主车间区域": "一车间更衣室",
                    "进车间时间": pd.Timestamp("2026-05-01 13:00:00"),
                    "出车间时间": pd.Timestamp("2026-05-01 18:00:00"),
                    "单次在车间秒数": 18000,
                    "进门禁点": "A进",
                    "出门禁点": "A出",
                    "进记录来源": "day2",
                    "出记录来源": "day2",
                },
                {
                    "人员姓名": "张三",
                    "工号": "1001",
                    "主车间区域": "一车间更衣室",
                    "进车间时间": pd.Timestamp("2026-05-02 20:10:00"),
                    "出车间时间": pd.Timestamp("2026-05-02 23:30:00"),
                    "单次在车间秒数": 12000,
                    "进门禁点": "A进",
                    "出门禁点": "A出",
                    "进记录来源": "night1",
                    "出记录来源": "night1",
                },
                {
                    "人员姓名": "张三",
                    "工号": "1001",
                    "主车间区域": "一车间更衣室",
                    "进车间时间": pd.Timestamp("2026-05-03 00:20:00"),
                    "出车间时间": pd.Timestamp("2026-05-03 07:00:00"),
                    "单次在车间秒数": 24000,
                    "进门禁点": "A进",
                    "出门禁点": "A出",
                    "进记录来源": "night2",
                    "出记录来源": "night2",
                },
            ]
        )
        primary_areas = pd.DataFrame(
            [
                {
                    "人员姓名": "张三",
                    "工号": "1001",
                    "有效记录数": 4,
                    "主车间区域": "一车间更衣室",
                }
            ]
        )

        sessions = assign_shifts_to_sessions(raw_sessions)
        self.assertEqual(sessions["班次"].tolist(), ["白班", "白班", "夜班", "夜班"])

        shifted_primary_areas = add_shift_to_primary_areas(primary_areas, sessions)
        self.assertEqual(
            shifted_primary_areas[["人员姓名", "工号", "班次"]].to_dict("records"),
            [
                {"人员姓名": "张三", "工号": "1001", "班次": "夜班"},
                {"人员姓名": "张三", "工号": "1001", "班次": "白班"},
            ],
        )

        _, daily_sheet, _, monthly_sheet = build_output_tables(sessions)
        self.assertEqual(
            daily_sheet[["班次", "统计日期", "当天在车间时长"]].to_dict("records"),
            [
                {"班次": "夜班", "统计日期": pd.Timestamp("2026-05-02"), "当天在车间时长": "10:00:00"},
                {"班次": "白班", "统计日期": pd.Timestamp("2026-05-01"), "当天在车间时长": "08:40:00"},
            ],
        )
        self.assertEqual(
            monthly_sheet[["班次", "统计月份", "当月在车间时长"]].to_dict("records"),
            [
                {"班次": "夜班", "统计月份": "2026-05", "当月在车间时长": "10:00:00"},
                {"班次": "白班", "统计月份": "2026-05", "当月在车间时长": "08:40:00"},
            ],
        )


class LicenseTests(unittest.TestCase):
    def test_admin_expire_date_normalization_accepts_timezone_timestamp(self) -> None:
        self.assertEqual(
            normalize_expire_date("2026-05-01T16:00:00+00:00"),
            datetime.fromisoformat("2026-05-01T16:00:00+00:00").astimezone().date(),
        )
        self.assertEqual(
            normalize_expire_date("2026-05-01"),
            date(2026, 5, 1),
        )
        self.assertEqual(
            normalize_expire_date("2026-05-04T16:00:00+00:00"),
            datetime.fromisoformat("2026-05-04T16:00:00+00:00").astimezone().date(),
        )

    def test_license_roundtrip_and_validation(self) -> None:
        machine_code = "ABCD-1234-EFGH-5678-IJKL"
        expires_on = date(2026, 12, 31)

        license_key = generate_license_key(machine_code, expires_on)
        payload = decode_license_key(license_key)

        self.assertEqual(payload.machine_code, machine_code)
        self.assertEqual(payload.expires_on, expires_on)

        validated = validate_license_key(license_key, machine_code, today=date(2026, 5, 1))
        self.assertEqual(validated, payload)

    def test_machine_fingerprint_uses_windows_hardware_and_username(self) -> None:
        with (
            patch("license_utils.os.name", "nt"),
            patch("license_utils._read_windows_username", return_value="ghwg"),
            patch("license_utils._read_windows_machine_guid", return_value="machine-guid-001"),
            patch("license_utils._read_windows_disk_serial", return_value="disk-serial-002"),
            patch("license_utils._read_windows_system_drive_volume_serial", return_value="1a2b-3c4d"),
            patch("license_utils.platform.machine", return_value="AMD64"),
            patch("license_utils.platform.system", return_value="Windows"),
        ):
            self.assertEqual(
                license_utils._machine_fingerprint_source(),
                "GHWG|MACHINE-GUID-001|DISK-SERIAL-002|1A2B-3C4D|AMD64|WINDOWS",
            )

    def test_machine_code_uses_mac_only_as_last_resort(self) -> None:
        with (
            patch("license_utils.os.name", "nt"),
            patch("license_utils._read_windows_username", return_value=""),
            patch("license_utils._read_windows_machine_guid", return_value=""),
            patch("license_utils._read_windows_disk_serial", return_value=""),
            patch("license_utils._read_windows_system_drive_volume_serial", return_value=""),
            patch("license_utils.platform.machine", return_value=""),
            patch("license_utils.platform.system", return_value=""),
            patch("license_utils.uuid.getnode", return_value=0x123456789ABC),
        ):
            self.assertEqual(
                license_utils._machine_fingerprint_source(),
                "0X123456789ABC",
            )
            self.assertRegex(get_machine_code(), r"^[A-F0-9]{4}(?:-[A-F0-9]{4}){4}$")

    def test_license_rejects_wrong_machine_and_expired_date(self) -> None:
        machine_code = "ABCD-1234-EFGH-5678-IJKL"
        license_key = generate_license_key(machine_code, date(2026, 5, 1))

        with self.assertRaises(LicenseError):
            validate_license_key(license_key, "WRONG-MACHINE", today=date(2026, 4, 1))

        with self.assertRaises(LicenseError):
            validate_license_key(license_key, machine_code, today=date(2026, 5, 2))

    def test_license_can_be_saved_and_loaded(self) -> None:
        license_key = generate_license_key("ABCD-1234-EFGH-5678-IJKL", date(2026, 10, 1))
        with tempfile.TemporaryDirectory() as tmpdir:
            base_dir = Path(tmpdir)
            save_activated_license(license_key, base_dir=base_dir)
            self.assertEqual(load_saved_license(base_dir=base_dir), license_key)
            clear_saved_license(base_dir=base_dir)
            self.assertEqual(load_saved_license(base_dir=base_dir), "")

    def test_license_can_overwrite_existing_saved_license(self) -> None:
        old_license = generate_license_key("ABCD-1234-EFGH-5678-IJKL", date(2026, 10, 1))
        new_license = generate_license_key("ABCD-1234-EFGH-5678-IJKL", date(2026, 12, 31))
        with tempfile.TemporaryDirectory() as tmpdir:
            base_dir = Path(tmpdir)
            save_activated_license(old_license, base_dir=base_dir)
            save_activated_license(new_license, base_dir=base_dir)
            self.assertEqual(load_saved_license(base_dir=base_dir), new_license)

    def test_legacy_license_file_is_migrated_to_new_path(self) -> None:
        license_key = generate_license_key("ABCD-1234-EFGH-5678-IJKL", date(2026, 10, 1))
        with tempfile.TemporaryDirectory() as tmpdir:
            base_dir = Path(tmpdir)
            legacy_target = get_legacy_license_file_path(base_dir=base_dir)
            legacy_target.parent.mkdir(parents=True, exist_ok=True)
            legacy_target.write_text('{"license_key": "%s"}' % license_key, encoding="utf-8")

            loaded = load_saved_license(base_dir=base_dir)
            self.assertEqual(loaded, license_key)
            self.assertFalse(legacy_target.exists())
            self.assertTrue(get_license_file_path(base_dir=base_dir).exists())

    def test_time_integrity_state_can_be_overwritten(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            base_dir = Path(tmpdir)
            first = verify_system_time_integrity(base_dir=base_dir)
            second = verify_system_time_integrity(base_dir=base_dir)
            self.assertTrue(first.is_valid)
            self.assertTrue(second.is_valid)


class PaginationLogicTests(unittest.TestCase):
    def test_total_pages_math_for_default_page_size(self) -> None:
        total_rows = 121
        page_size = 50
        total_pages = max((total_rows + page_size - 1) // page_size, 1)
        self.assertEqual(total_pages, 3)

    def test_page_slice_boundaries(self) -> None:
        total_rows = 121
        page_size = 50
        current_page = 3
        start_index = (current_page - 1) * page_size
        end_index = min(start_index + page_size, total_rows)
        self.assertEqual(start_index, 100)
        self.assertEqual(end_index, 121)


class TimeIntegrityTests(unittest.TestCase):
    def test_time_integrity_allows_normal_forward_progress(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            base_dir = Path(tmpdir)
            with patch("license_utils.datetime") as mocked_datetime, patch("license_utils.time.monotonic") as mocked_monotonic:
                mocked_datetime.now.return_value = datetime(2026, 5, 1, 8, 0, 0)
                mocked_datetime.fromisoformat.side_effect = datetime.fromisoformat
                mocked_monotonic.return_value = 1000.0
                first_result = verify_system_time_integrity(base_dir=base_dir)
                self.assertTrue(first_result.is_valid)

                mocked_datetime.now.return_value = datetime(2026, 5, 1, 8, 10, 0)
                mocked_monotonic.return_value = 1600.0
                second_result = verify_system_time_integrity(base_dir=base_dir)
                self.assertTrue(second_result.is_valid)

    def test_time_integrity_blocks_time_rollback(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            base_dir = Path(tmpdir)
            refresh_time_integrity_state(base_dir=base_dir, current_time=datetime(2026, 5, 1, 10, 0, 0))
            state_path = get_time_state_file_path(base_dir=base_dir)
            self.assertTrue(state_path.exists())

            with patch("license_utils.datetime") as mocked_datetime, patch("license_utils.time.monotonic") as mocked_monotonic:
                mocked_datetime.now.return_value = datetime(2026, 5, 1, 9, 0, 0)
                mocked_datetime.fromisoformat.side_effect = datetime.fromisoformat
                mocked_monotonic.return_value = 1200.0
                result = verify_system_time_integrity(base_dir=base_dir)
                self.assertFalse(result.is_valid)
                self.assertIn("系统时间", result.message)


if __name__ == "__main__":
    unittest.main()
