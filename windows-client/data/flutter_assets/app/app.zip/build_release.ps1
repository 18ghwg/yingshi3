param(
    [ValidateSet("all", "client", "admin")]
    [string]$Target = "all",
    [string]$ProjectRootPath = ""
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($ProjectRootPath)) {
    $ProjectRoot = (Get-Location).Path
} else {
    $ProjectRoot = [System.IO.Path]::GetFullPath($ProjectRootPath)
}
$BuildRoot = Join-Path $ProjectRoot "build"
$DistRoot = Join-Path $BuildRoot "dist"
$ClientBuildOutput = Join-Path $BuildRoot "windows"
$ClientDist = Join-Path $DistRoot "windows-client"
$AdminDist = Join-Path $DistRoot "windows-license-admin"
$AdminShellRoot = Join-Path $BuildRoot "admin-shell"
$SharedSitePackages = Join-Path $BuildRoot "site-packages"
$AdminAppRoot = Join-Path $ProjectRoot "license_admin_app"
$AdminZipPath = Join-Path $AdminShellRoot "build\\windows\\x64\\runner\\Release\\data\\flutter_assets\\app\\app.zip"
$AdminZipHashPath = "$AdminZipPath.hash"

$BuildRoot = [System.IO.Path]::GetFullPath($BuildRoot)
$DistRoot = [System.IO.Path]::GetFullPath($DistRoot)
$ClientBuildOutput = [System.IO.Path]::GetFullPath($ClientBuildOutput)
$ClientDist = [System.IO.Path]::GetFullPath($ClientDist)
$AdminDist = [System.IO.Path]::GetFullPath($AdminDist)
$AdminShellRoot = [System.IO.Path]::GetFullPath($AdminShellRoot)
$SharedSitePackages = [System.IO.Path]::GetFullPath($SharedSitePackages)
$AdminAppRoot = [System.IO.Path]::GetFullPath($AdminAppRoot)
$AdminZipPath = [System.IO.Path]::GetFullPath($AdminZipPath)
$AdminZipHashPath = [System.IO.Path]::GetFullPath($AdminZipHashPath)
$TempRoot = Join-Path ([System.IO.Path]::GetTempPath()) "workshop-duration-stats-build"

function Get-SevenZipPath {
    $candidates = @(
        "C:\Program Files\7-Zip\7z.exe",
        "C:\Program Files (x86)\7-Zip\7z.exe",
        "C:\Program Files (x86)\Huorong\AppStore\bin\7z.exe",
        "C:\Program Files\NVIDIA Corporation\NVIDIA GeForce Experience\7z.exe"
    )

    foreach ($candidate in $candidates) {
        if (Test-Path $candidate) {
            return $candidate
        }
    }

    $command = Get-Command 7z.exe -ErrorAction SilentlyContinue
    if ($command) {
        return $command.Source
    }

    return $null
}

function Copy-Folder {
    param(
        [Parameter(Mandatory = $true)][string]$Source,
        [Parameter(Mandatory = $true)][string]$Destination
    )

    if (!(Test-Path $Source)) {
        throw "Source folder does not exist: $Source"
    }

    New-Item -ItemType Directory -Path $Destination -Force | Out-Null

    $null = robocopy $Source $Destination /MIR /NFL /NDL /NJH /NJS /NP /R:1 /W:1
    if ($LASTEXITCODE -gt 7) {
        throw "robocopy failed with exit code: $LASTEXITCODE"
    }
}

function Update-AdminAppZip {
    if (!(Test-Path $AdminShellRoot)) {
        throw "Admin shell folder is missing: $AdminShellRoot"
    }

    $stage = Join-Path $TempRoot "admin_zip_stage"
    if (Test-Path $stage) {
        Remove-Item -LiteralPath $stage -Recurse -Force
    }
    New-Item -ItemType Directory -Path $stage | Out-Null

    foreach ($name in @("app.py", "license_admin.py", "license_utils.py", "_shared_license_utils.py", "pyproject.toml", "README.md")) {
        Copy-Item -LiteralPath (Join-Path $AdminAppRoot $name) -Destination $stage
    }

    $assetsSrc = Join-Path $AdminAppRoot "assets"
    if (Test-Path $assetsSrc) {
        Copy-Item -LiteralPath $assetsSrc -Destination (Join-Path $stage "assets") -Recurse
    }

    $tempZipPath = Join-Path $TempRoot "admin_app.zip"
    if (Test-Path $tempZipPath) {
        Remove-Item -LiteralPath $tempZipPath -Force -ErrorAction SilentlyContinue
    }

    Compress-Archive -Path (Join-Path $stage "*") -DestinationPath $tempZipPath -CompressionLevel Optimal

    $adminZipBackupPath = "$AdminZipPath.bak"
    if (Test-Path $adminZipBackupPath) {
        Remove-Item -LiteralPath $adminZipBackupPath -Force -ErrorAction SilentlyContinue
    }

    if (Test-Path $AdminZipPath) {
        try {
            [System.IO.File]::SetAttributes($AdminZipPath, [System.IO.FileAttributes]::Normal)
        } catch {
        }

        try {
            [System.IO.File]::Delete($AdminZipPath)
        } catch {
            try {
                [System.IO.File]::Move($AdminZipPath, $adminZipBackupPath)
            } catch {
            }
        }
    }

    [System.IO.File]::Copy($tempZipPath, $AdminZipPath, $true)
    Remove-Item -LiteralPath $tempZipPath -Force -ErrorAction SilentlyContinue

    $stream = [System.IO.File]::OpenRead($AdminZipPath)
    try {
        $sha256 = [System.Security.Cryptography.SHA256]::Create()
        try {
            $hashBytes = $sha256.ComputeHash($stream)
        } finally {
            $sha256.Dispose()
        }
    } finally {
        $stream.Dispose()
    }
    $hash = ([System.BitConverter]::ToString($hashBytes)).Replace("-", "").ToLower()
    Set-Content -Path $AdminZipHashPath -Value $hash -Encoding ascii

    Remove-Item -LiteralPath $stage -Recurse -Force
}

function Build-ClientRelease {
    if (Test-Path $ClientBuildOutput) {
        Remove-Item -LiteralPath $ClientBuildOutput -Recurse -Force
    }

    [Console]::InputEncoding = [System.Text.UTF8Encoding]::new()
    [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new()
    $OutputEncoding = [System.Text.UTF8Encoding]::new()
    chcp 65001 > $null
    $env:PYTHONIOENCODING = "utf-8"
    $env:PYTHONUTF8 = "1"
    $env:LANG = "en_US.UTF-8"

    Push-Location $ProjectRoot
    try {
        & flet build windows . --yes --no-rich-output -v
        if ($LASTEXITCODE -ne 0) {
            throw "Client build failed with exit code: $LASTEXITCODE"
        }
    } finally {
        Pop-Location
    }

    if (!(Test-Path $ClientBuildOutput)) {
        throw "Client build output folder is missing: $ClientBuildOutput"
    }
}

function Sync-ClientDist {
    Build-ClientRelease
    Copy-Folder -Source $ClientBuildOutput -Destination $ClientDist
}

function Sync-AdminDist {
    $adminRelease = Join-Path $AdminShellRoot "build\\windows\\x64\\runner\\Release"
    if (!(Test-Path $adminRelease)) {
        throw "Admin Release folder is missing: $adminRelease"
    }
    if (!(Test-Path $SharedSitePackages)) {
        throw "Shared site-packages folder is missing: $SharedSitePackages"
    }

    try {
        Update-AdminAppZip
    } catch {
        Write-Warning "Admin app package refresh was skipped: $($_.Exception.Message)"
    }
    Copy-Folder -Source $adminRelease -Destination $AdminDist
}

New-Item -ItemType Directory -Path $DistRoot -Force | Out-Null

switch ($Target) {
    "client" {
        Sync-ClientDist
    }
    "admin" {
        Sync-AdminDist
    }
    "all" {
        Sync-ClientDist
        Sync-AdminDist
    }
}

Write-Output "Done: $Target"
